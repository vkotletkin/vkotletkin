### Проблема

При контейнеризации BentoML должен загружать базовые образы из nexus-а. Полезно будет использовать базовые образы, которые использует сам BentoML, если в bentofile не указать base_image. Хочется иметь возможность автоматически скачать и загрузить в свой docker-registry поддерживаемые образы.  При этом нужно иметь возможность загрузить все поддерживаемые образы или только используемые по какому-то критерию (дистрибутив, версия python или cuda и т.д.) 

### Установка

Установите BentoML нужной вам версии.

```bash
python -m venv venv 
source venv/bin/activate
pip install bentoml==$BENTOML_VERSION
```

### Использование

Чтобы скачать базовый образ для bentoml-сервиса с представленной конфигурацией нужно запустить скрипт с уточнением дистрибутива и версии питона.
```yaml
bentofile.yaml

docker:
  distro: "debian"
  python_version: "3.10"
```

```bash
python bentoml_image_loader.py --distro debian --spec-type python --spec-version 3.10 --registry my.nexus.docker-registry --username {NEXUS_USER} --password ${NEXUS_PASSWORD} 
```

После этого можно изменить конфигурацию bento-сервиса.
```yaml 
bentofile.yaml

docker:
  base_image: "my.nexus.docker-registry"
```

Чтобы скачать все поддерживаемые образы просто не задавайте аргументы  `--distro, --spec-type` и `--spec-version`. Чтобы локальные копии образов удалялись после загрузки в registry добавьте флаг `--rm`.
```bash
python bentoml_image_loader.py --registry my.nexus.docker-registry --username {NEXUS_USER} --password ${NEXUS_PASSWORD} --rm
```

Более подробную подсказку по использованию можно увидеть при запуске с флагом `--help`.
```bash
user@group:~$ python bentoml_image_loader.py --help

usage: Bentoml base image loader [-h] [--distro DISTRO [DISTRO ...]] [--spec-type SPEC_TYPE [SPEC_TYPE ...]]
                                 [--spec-version SPEC_VERSION [SPEC_VERSION ...]] [--registry REGISTRY] [--username USERNAME] [--password PASSWORD] [--rm]

options:
  -h, --help            show this help message and exit
  --distro DISTRO [DISTRO ...]
                        List of distributions (e.g. ['amazonlinux', 'ubi8', 'debian', 'alpine']) to download
  --spec-type SPEC_TYPE [SPEC_TYPE ...]
                        List of spec types (e.g. ['python', 'miniconda', 'cuda']) to download
  --spec-version SPEC_VERSION [SPEC_VERSION ...]
                        List of versions of spec type (e.g. for python ['3.8', '3.9', '3.10', '3.11'] or cuda ['12.0.0', '12.0.1', '12.1.0', '12.1.1', '11.8.0', '11.7.1', '11.6.2', '11.4.3', '11.2.2']) to download
  --registry REGISTRY   Registry to which the image will be push
  --username USERNAME   Username in Docker (for push request)
  --password PASSWORD   Password in Docker (for push request)
  --rm                  If the flag is set, the images will be deleted after pushing to the registry

```

