import logging
import typing as t
from argparse import ArgumentParser
from os.path import join

import bentoml._internal.container.frontend.dockerfile as bentoml_docker
import docker

logging.getLogger().setLevel(logging.INFO)


def read_args():
    parser = ArgumentParser(prog='Bentoml base image loader')

    parser.add_argument(
        '--distro',
        nargs='+',
        required=False,
        default=None,
        help=f'List of distributions (e.g. {bentoml_docker.CONTAINER_SUPPORTED_DISTROS}) to download'
    )
    parser.add_argument(
        '--spec-type',
        nargs='+',
        required=False,
        default=None,
        help=f'List of spec types (e.g. {bentoml_docker.SUPPORTED_RELEASE_TYPES}) to download'
    )
    parser.add_argument(
        '--spec-version',
        nargs='+',
        required=False,
        default=None,
        help=f'List of versions of spec type (e.g. for python {bentoml_docker.SUPPORTED_PYTHON_VERSIONS} or cuda {bentoml_docker.SUPPORTED_CUDA_VERSIONS}) to download'
    )

    parser.add_argument(
        '--registry',
        required=False,
        default='nexus.baltinfocom.ru/docker-private/bentoml-base',
        help='Registry to which the image will be push'
    )
    parser.add_argument(
        '--username',
        required=False,
        default='',
        help='Username in Docker (for push request)'
    )
    parser.add_argument(
        '--password',
        required=False,
        default='',
        help='Password in Docker (for push request)'
    )

    parser.add_argument(
        '--rm',
        action='store_true',
        help='If the flag is set, the images will be deleted after pushing to the registry'
    )

    return parser.parse_args()


def get_images(
    distros: t.Optional[t.List[str]],
    spec_types: t.Optional[t.List[str]],
    spec_versions: t.Optional[t.List[str]],
) -> t.List[str]:
    logging.info(f'The search for images with parameters {distros, spec_types, spec_versions} has been launched')

    images = []

    distros = bentoml_docker.CONTAINER_SUPPORTED_DISTROS if distros is None else distros
    spec_types = bentoml_docker.SUPPORTED_RELEASE_TYPES if spec_types is None else spec_types

    for spec_type in spec_types:
        supported_distros = bentoml_docker.get_supported_spec(spec_type)
        required_distros = set(distros) & set(supported_distros)
        if len(required_distros) == 0:
            logging.warn(f'None of the requested distros ({distros}) match the ones supported ({supported_distros}) for the {spec_type}.')

        for distro in required_distros:
            supported_versions = bentoml_docker.CONTAINER_METADATA[distro].get(f'supported_{spec_type}_versions')
            supported_versions = [''] if supported_versions is None else supported_versions
            if spec_versions is None:
                required_versions = supported_versions
            else:
                required_versions = set(supported_versions) & set(spec_versions)

            if len(required_distros) == 0:
                logging.warn(f'None of the requested versions ({spec_versions}) match the ones supported ({supported_versions}) for the {spec_type} and {distro}.')

            for spec_version in required_versions:
                image = bentoml_docker.CONTAINER_METADATA[distro][spec_type]['image']
                images.append(image.format(spec_version=spec_version))

    return images


def docker_load(client, image_tag, registry, auth_config, rm):
    logging.info(f'The beginning of downloading the {image_tag} image')

    image = client.images.pull(image_tag)

    new_image_tag = join(registry, image_tag)
    image.tag(new_image_tag)

    logging.info(f'Old image tag: {image_tag}. New image tag: {new_image_tag}.')

    resp = client.images.push(
        new_image_tag,
        stream=True,
        decode=True,
        auth_config=auth_config,
    )

    for line in resp:
        logging.info(line)

    if rm:
        client.images.remove(image_tag)
        client.images.remove(new_image_tag)

    logging.info(f'Image {new_image_tag} has been successfully uploaded')



def main():
    args = read_args()

    images = get_images(
        distros=args.distro,
        spec_types=args.spec_type,
        spec_versions=args.spec_version
    )

    logging.info(f'Selected images to upload to registry {images}')

    auth_config = {
        'username': args.username,
        'password': args.password,
        'registry': args.registry,
    }

    client = docker.from_env()

    for image_tag in images:
        try:
            docker_load(client, image_tag, args.registry, auth_config, args.rm)
        except Exception as e:
            logging.error(f'Failed to load the {image_tag}', e)


if __name__ == '__main__':
    main()
