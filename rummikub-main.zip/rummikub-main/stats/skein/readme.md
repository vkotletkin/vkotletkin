### Configure

Напишите `.env` файл основываясь на `.env.template`.

Напишите `spec.yaml` файл основываясь на `spec.yaml.template`.

### Preparation example

```bash
conda create -n skein python=3.8
conda activate skein
conda install -c conda-forge conda-pack
pip install skein
conda pack -o conda_env.tar.gz
```

### Run

```bash
su hdfs

export SKEIN_DRIVER_HOST=0.0.0.0 SKEIN_DRIVER_PORT=40000
skein driver start

APPID=`skein application submit spec.yaml`
```