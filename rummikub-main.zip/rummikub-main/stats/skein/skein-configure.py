import socket
import sys

import skein

try:
    app = skein.ApplicationClient.from_current()

    host = socket.gethostbyname(socket.gethostname())
    port = sys.argv[1]
    address = f'{host}:{port}'

    key = 'stat_bento_service.address'
    value = address.encode()

    app.kv.put(key, value, owner=skein.properties.container_id)
except Exception as e:
    sys.exit(1)
