"""
This module contains the schema of API output.

All schemas declare as typing.Annotated. Format:
    real return type
    pseudo struct
    description
    output example
"""

from typing import Annotated

import numpy as np


SimpleOutput = Annotated[
    np.ndarray,
    list[str | int],
    'Returns a simple sequence of defined classes.',
    '[1, 2, 3, 4, ...]',
]
IdOutput = Annotated[
    np.ndarray,
    list[tuple[str | int, int | str]],
    'Returns a mapping of the id (from the id_col column) to the predicted class.',
    '[("0", 0), ("1", 1), ("2", 0), ("3", 1), ...]',
]
ProbOutput = Annotated[
    np.ndarray,
    list[list[float]],
    'Returns a set of probabilities of belonging to each class for each element.',
    '[[0.1, 0.2, 0.7], [0.9, 0.09, 0.01], [0.2, 0.5, 0.3], ...]',
]
ProbIdOutput = Annotated[
    np.ndarray,
    list[tuple[str | int, list[float]]],
    'For each element, returns the element id and a set of probabilities of classes.',
    '[("1", [0.1, 0.2, 0.7]), ("2", [0.9, 0.09, 0.01]), ...]',
]
Output = SimpleOutput | IdOutput | ProbOutput | ProbIdOutput
