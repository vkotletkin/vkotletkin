import logging
from pathlib import Path
from typing import Annotated

import yaml
from pydantic_settings import BaseSettings

DEFAULT_CONFIG_PATH = Path('config.yaml')


class ServiceConfig(BaseSettings):
    default_model_name: str = 'gender_prediction_model'


class ModelStoreConfig(BaseSettings):
    mlflow_url: str = 'http://fake.url:5000'
    update_timeout: int = 120
    alias: str = 'deploy'


class Config(BaseSettings):
    bentoml_service_config: Annotated[dict, 'bentoml.service __init__ kwargs'] = {}
    service_instance_config: ServiceConfig = ServiceConfig()
    store_config: ModelStoreConfig = ModelStoreConfig()


def read_config(path: Path = DEFAULT_CONFIG_PATH):
    if path.is_file():
        with open(path, 'r') as rf:
            config = Config(**yaml.safe_load(rf))
    else:
        logging.warning(f'Config file {path} not found.')
        config = Config()

    logging.info('Configuration Options:', config.model_dump())
    return config


config = read_config()
