from collections import namedtuple
from time import time

import mlflow
from catboost import CatBoostClassifier
from mlflow.entities.model_registry.model_version import ModelVersion

Model = namedtuple('Model', ['info', 'instance', 'last_check'])


class ModelStore:

    def __init__(
        self,
        mlflow_url: str,
        update_timeout: int,
        alias: str,
    ):
        self._client = mlflow.MlflowClient(mlflow_url)
        self._update_timeout = update_timeout
        self._alias = alias

        self._models: dict[str, Model] = {}

    def get_model_instance(self, name: str) -> CatBoostClassifier:
        if name not in self._models:
            model = self._load_model(name)
        else:
            model = self._update_model(self._models[name])

        self._models[name] = model

        return model.instance

    def _update_model(self, model: Model) -> Model:
        check_time = time()
        if check_time - model.last_check > self._update_timeout:
            new_info = self._client.get_model_version_by_alias(
                model.info.name, self._alias,
            )
            if int(new_info.version) > int(model.info.version):
                return self._load_model(model.info.name, info=new_info)

        return Model(info=model.info, instance=model.instance, last_check=check_time)

    def _load_model(self, name: str, model_version: ModelVersion | None = None) -> Model:
        if model_version is None:
            model_version = self._client.get_model_version_by_alias(name, self._alias)

        instance = mlflow.catboost.load_model(model_version.source)
        return Model(info=model_version, instance=instance, last_check=time())
