from typing import Annotated

import bentoml
import pandas as pd
from bentoml.exceptions import BentoMLException
from bentoml.metrics import Histogram
from bentoml.validators import DataframeSchema

from service.config import config
from service.model_store import ModelStore
from service.schemas import (
    IdOutput,
    Output,
    ProbIdOutput,
    ProbOutput,
    SimpleOutput,
)

REQUEST_TIME = Histogram(
    'request_processing_seconds', 'Time spent processing request',
)
INFERENCE_TIME = Histogram(
    'ml_model_inference_seconds', 'Time spent model inference',
)
MODEL_UPDATE_TIME = Histogram(
    'ml_model_update_seconds', 'Time spent updating mlflow model info',
)


@bentoml.service(**config.bentoml_service_config)
class StatService:

    def __init__(self):
        self._default_model_name = config.service_instance_config.default_model_name

        self._model_store = ModelStore(**config.store_config.dict())

    @bentoml.api(route='/predict', name='predict')
    def api_predict(
        self,
        df: Annotated[pd.DataFrame, DataframeSchema(orient='columns')],
        model_name: str | None,
        return_id: bool = False,
        id_col: str = 'id',
        return_prob: bool = False,
    ) -> Output:
        if model_name is None:
            model_name = self._default_model_name

        if return_id:
            return self._predict_map_id(
                df=df,
                model_name=model_name,
                id_col=id_col,
                return_prob=return_prob,
            )

        return self._predict(
            df=df,
            model_name=model_name,
            return_prob=return_prob,
        )

    def _predict_map_id(
        self, df: pd.DataFrame, model_name: str, id_col: str, return_prob: bool
    ) -> IdOutput | ProbIdOutput:
        if id_col not in df.columns:
            columns = df.columns.tolist()
            raise BentoMLException(
                f'Column "id" not found. Columns: {columns}',
            )

        prediction = self._predict(
            df=df,
            model_name=model_name,
            return_prob=return_prob,
        )
        return pd.concat([df.loc[id_col], prediction], axis=1)

    def _predict(
        self, df: pd.DataFrame, model_name: str, return_prob: bool,
    ) -> SimpleOutput | ProbOutput:
        with self.REQUEST_TIME.time():
            with self.MODEL_UPDATE_TIME.time():
                model = self._model_store.get_model_instance(model_name)

            with self.INFERENCE_TIME.time():
                prediction = model.predict(
                    df, 'Probability' if return_prob else 'Class',
                )

        return prediction
