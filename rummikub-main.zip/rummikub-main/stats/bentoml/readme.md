## Prepare env

```bash
export NEXUS_USER=... \
	   NEXUS_PASSWORD=... \
	   NEXUS_DOCKER_REGISTRY=...

docker login -u ${NEXUS_USER} -p ${NEXUS_PASSWORD} ${DOCKER_REGISTRY}
docker pull ${NEXUS_DOCKER_REGISTRY}/python:3.10-slim
docker tag ${NEXUS_DOCKER_REGISTRY}/python:3.10-slim python:3.10-slim
```

## Build docker container

```bash
bentoml build
bentoml containerize -t ${DOCKER_REGISTRY}/stat_service:latest stat_service:latest
```

## Uploading to the nexus

```bash
docker push ${DOCKER_REGISTRY}/stat_service:latest
```

## Configure

Пропишите переменные окружения в файле `.env` (можно основываться на шаблоне `.env.template`)

Пропишите конфигурацию сервиса в файле `config.yaml` (можно основываться на шаблоне `config.yaml.template`). Задайте поля 
 
 Раз в заданный промежуток времени (config.yaml, поле `store_config.update_timeout`) 


## Run docker container

```bash
docker run --rm -p 3000:3000 \
	--env-file .env \
	-v ./config.yaml:/home/bentoml/bento/src/config.yaml \
	${DOCKER_REGISTRY}/stat_service:latest
```

## Curl request example 

WARNING: This example is not valid for all models

```bash
curl -X 'POST' \
  'http://${BENTOML_HOST}:3000/predict' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d @example.json
``` 