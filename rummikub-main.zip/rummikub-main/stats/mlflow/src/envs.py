from pydantic import model_serializer
from pydantic_settings import BaseSettings, SettingsConfigDict


class StorageOptions(BaseSettings):
    model_config = SettingsConfigDict(case_sensitive=False)

    mlflow_s3_endpoint_url: str
    aws_access_key_id: str
    aws_secret_access_key: str

    @model_serializer
    def ser_model(self) -> dict[str, str | dict[str, str]]:
        return {
            'key': self.aws_access_key_id,
            'secret': self.aws_secret_access_key,
            'client_kwargs': {
                'endpoint_url': self.mlflow_s3_endpoint_url,
            },
        }
