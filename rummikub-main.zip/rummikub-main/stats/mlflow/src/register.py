import re
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any

import mlflow
from catboost import CatBoostClassifier
from evidently.report import Report
from evidently.test_suite import TestSuite
from mlflow.tracking import MlflowClient
from pydantic_settings import BaseSettings

EVIDENTLY_ARTIFACT_PATH = 'evidently'
MODEL_ARTIFACT_PATH = 'model'
RAW_DATASET_REPORT_NAME = 'raw_dataset_metrics'
TRANSFORMED_DATASET_REPORT_NAME = 'transformed_dataset_metrics'
DATASET_TEST_SUITE_NAME = 'dataset_test_suite'


def format_time(seconds: float) -> str:
    hours = int(seconds // 3600)
    seconds %= 3600
    minutes = int(seconds // 60)
    seconds = int(seconds % 60)

    return f"{hours:02}:{minutes:02}:{seconds:02}"


class RegisterStep:

    def __init__(
        self,
        model_name: str,
        allow_set_alias: bool,
        alias: str,
        project_config: BaseSettings,
    ):
        self._model_name = model_name
        self._allow_set_alias = allow_set_alias
        self._alias = alias
        self._project_config = project_config

    def register(
        self,
        model: CatBoostClassifier,
        hyperparameters: dict[str, Any],
        features: list[str],
        metrics: dict[str, float],
        raw_dataset_report: Report,
        transformed_dataset_report: Report,
        dataset_test_suite: TestSuite,
        analytic_time: float,
        train_time: float,
    ):
        with mlflow.start_run() as run:
            mlflow.catboost.log_model(
                cb_model=model,
                registered_model_name=self._model_name,
                artifact_path=MODEL_ARTIFACT_PATH,
            )
            mlflow.log_param('hyperparameters', hyperparameters)
            mlflow.log_param('features', features)
            mlflow.log_params(self._project_config.model_dump(exclude='storage_options'))

            self._log_metrics(metrics)

            self._log_report(raw_dataset_report, RAW_DATASET_REPORT_NAME)
            self._log_report(transformed_dataset_report, TRANSFORMED_DATASET_REPORT_NAME)

            self._log_report_as_html(dataset_test_suite, DATASET_TEST_SUITE_NAME)
            self._log_report_as_snapshot(dataset_test_suite, DATASET_TEST_SUITE_NAME)

            self._log_time(train_time, 'train_time')
            self._log_time(analytic_time, 'analytic_time')

            run_id = run.info.run_id

        if self._allow_set_alias:
            self._set_model_alias(run_id)

    def _log_metrics(self, metrics: dict[str, float]):
        special_charters = r'[:=;,.!?()\[\]{}<>\"\'\\/]'
        metrics = {
            re.sub(special_charters, ' ', name): value for name, value in metrics.items()
        }
        mlflow.log_metrics(metrics)

    def _log_report(self, report: Report, report_name: str):
        self._log_report_as_tables(report, report_name)
        self._log_report_as_html(report, report_name)
        self._log_report_as_snapshot(report, report_name)

    def _log_report_as_tables(self, report: Report, report_name: str):
        for table_name, table in report.as_dataframe().items():
            artifact_file = Path(
                EVIDENTLY_ARTIFACT_PATH,
                f'{report_name}_{table_name}.json',
            )
            mlflow.log_table(data=table, artifact_file=str(artifact_file))

    def _log_report_as_html(self, report: Report | TestSuite, report_name: str):
        with TemporaryDirectory() as tmp_dir:
            report_html_path = f'{tmp_dir}/{report_name}.html'
            report.save_html(report_html_path)
            mlflow.log_artifact(
                local_path=report_html_path, artifact_path=EVIDENTLY_ARTIFACT_PATH,
            )

    def _log_report_as_snapshot(self, report: Report | TestSuite, report_name: str):
        with TemporaryDirectory() as tmp_dir:
            report_snapshot_path = f'{tmp_dir}/{report_name}.snapshot'
            report.save(report_snapshot_path)
            mlflow.log_artifact(
                local_path=report_snapshot_path, artifact_path=EVIDENTLY_ARTIFACT_PATH,
            )

    def _log_time(self, time: float, name: str):
        mlflow.log_param(name, format_time(time))

    def _set_model_alias(self, run_id: str):
        model_uri = f'runs:/{run_id}/{MODEL_ARTIFACT_PATH}'
        model_version_info = mlflow.register_model(model_uri, self._model_name)
        MlflowClient().set_registered_model_alias(
            self._model_name, self._alias, model_version_info.version,
        )
