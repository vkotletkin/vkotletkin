from typing import Any

import pandas as pd


class IngestStep:

    def __init__(
        self, data_location: str, storage_options: dict[str, Any], id_col: int | str,
    ):
        self._data_location = data_location
        self._storage_options = storage_options
        self._id_col = id_col

    def ingest(self):
        return pd.read_csv(
            self._data_location,
            storage_options=self._storage_options,
            index_col=self._id_col,
        )
