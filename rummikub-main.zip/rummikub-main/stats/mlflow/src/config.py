import json
from pathlib import Path
from typing import Any

from catboost import EFeaturesSelectionAlgorithm, EShapCalcType
from pydantic import Field, computed_field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from envs import StorageOptions


class MLProjectConfig(BaseSettings):
    model_config = SettingsConfigDict()

    data_location: str = Field(
        default='dataset.csv',
        description="""
        Location of the data file
        """,
    )
    target_col: str = Field(
        default='target',
        description="""
        Target column for the model
        """,
    )
    test_size: float = Field(
        default=0.1,
        description="""
        Size of the test set
        """,
    )
    metrics: list[str] = Field(
        default=[
            'Precision',
            'Recall',
            'F1',
            'MCC',
            'Accuracy',
            'AUC',
        ],
        description="""
        Metrics to evaluate the model
        """,
    )
    model_name: str = Field(
        default='mlproject_model',
        description="""
        Name of the model
        """,
    )
    id_col_name: str = Field(
        default='id',
        description="""
        The column with this name displays the entity IDs
        in the dataset and will be deleted during training
        """,
    )
    default_params: dict[str, Any] = Field(
        default={'iterations': 1000},
        description="""
        A json dictionary containing arguments for
        initializing the CatBoostClassifier model
        https://catboost.ai/en/concepts/python-reference_catboostclassifier
        """,
    )
    selection_params: dict[str, Any] = Field(
        default={
            'num_features_to_select': 150,
            'shap_calc_type': 'Regular',
            'algorithm': 'RecursiveByLossFunctionChange',
            'steps': 5,
        },
        description="""
        A json dictionary containing arguments CatBoostClassifier.select_features method
        https://catboost.ai/en/concepts/python-reference_catboostclassifier#select_features
        """,
    )
    grid_params: dict[str, Any] = Field(
        default={
            'learning_rate': [0.01, 0.03, 0.06, 0.1],
            'l2_leaf_reg': [2, 3, 4],
            'boosting_type': ['Ordered', 'Plain'],
            'depth': [2, 3, 5, 6],
        },
        description="""
        A json dictionary containing arguments for
        CatBoostClassifier.grid_search (parameter grid search)
        https://catboost.ai/en/docs/concepts/python-reference_catboostclassifier_grid_search#description
        """,
    )
    allow_set_alias: bool = Field(
        default=True,
        description="""
        If the "true" model is set as an alias for the registered model
        """,
    )
    alias: str = Field(
        default='mlproject_latest',
        description="""
        If the "allow_set_alias" parameter is set to "true", the model
        will set this aliasfor the model. Otherwise, it will ignore it
        """,
    )
    label_map: dict[str, Any] | None = Field(
        default=None,
        description="""
        A json dictionary containing a mapping for labels.
        For example: '{'man': 1, 'woman': 0}'
        """,
    )
    label_placeholder: Any = Field(
        default='',
        description="""
        If "label_map" is setted and key from dataset
        not found value will replaced with "placeholder".
        """,
    )

    @computed_field(repr=False)
    @property
    def storage_options(self) -> dict[str, str | dict[str, str]] | None:
        if self.data_location.startswith('s3://'):
            return StorageOptions().model_dump()

        return None

    @field_validator('metrics')
    @classmethod
    def split_metrics(cls, field_value):
        if isinstance(field_value, str):
            return field_value.split(',')
        return field_value

    @field_validator('selection_params')
    @classmethod
    def validate_selection_params(cls, field_value) -> dict[str, Any]:
        if isinstance(field_value, dict):
            field_value['num_features_to_select'] = field_value.get(
                'num_features_to_select', 100,
            )
            field_value['algorithm'] = EFeaturesSelectionAlgorithm(
                field_value.get('algorithm', 'RecursiveByLossFunctionChange'),
            )
            field_value['shap_calc_type'] = EShapCalcType(
                field_value.get('shap_calc_type', 'Regular'),
            )
            if field_value.get('train_final_model') is True:
                raise ValueError('The "train_final_model" field cannot be "true"')

            field_value['train_final_model'] = False

            return field_value

        raise TypeError('"selection_params" field must be a dict')

    @field_validator('grid_params')
    @classmethod
    def validate_grid_params(cls, field_value) -> dict[str, Any]:
        if isinstance(field_value, dict):
            if field_value.get('refit') is False:
                raise ValueError('The "refit" field cannot be "false"')

            return field_value

        raise TypeError('"grid_params" field must be a dict')

    @classmethod
    def from_json(cls, path: Path) -> 'MLProjectConfig':
        with open(path) as rf:
            data = json.load(rf)

        return cls(**data)

    @field_validator('label_map')
    @classmethod
    def validate_label_map(cls, field_value) -> dict[str, Any] | None:
        if isinstance(field_value, dict):
            return field_value

        if isinstance(field_value, str) and field_value != '':
            return json.loads(field_value)

        return None
