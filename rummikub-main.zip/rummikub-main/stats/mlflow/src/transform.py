from typing import Any

import pandas as pd


class TransformStep:

    def __init__(
        self,
        id_col_name: str,
        target_col: str,
        label_map: dict[str, Any],
        label_placeholder: str,
    ):
        self._id_col_name = id_col_name
        self._target_col = target_col
        self._label_placeholder = label_placeholder
        self._label_map = label_map

    def transform(self, dataset: pd.DataFrame) -> pd.DataFrame:
        dataset = dataset.copy(deep=True)
        self._drop_id(dataset)
        self._map_label(dataset)
        return dataset

    def _drop_id(self, dataset: pd.DataFrame):
        dataset.drop(columns=[self._id_col_name], errors='ignore', inplace=True)

    def _map_label(self, dataset: pd.DataFrame):
        if self._label_map:
            dataset[self._target_col] = (
                dataset[self._target_col]
                .astype(str)
                .map(self._label_map)
                .fillna(self._label_placeholder)
            )
