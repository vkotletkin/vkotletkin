from time import time

from evidently import ColumnMapping
from evidently.test_preset import (
    DataQualityTestPreset,
    DataStabilityTestPreset,
)
from evidently.test_suite import TestSuite

from args import MLProjectArgs
from config import MLProjectConfig
from dataset_metrics import DatasetMetricsReport, Preset
from evaluate import EvaluateStep
from ingest import IngestStep
from register import RegisterStep
from split import SplitStep
from train import TrainStep
from transform import TransformStep


class MLProject:

    def __init__(
        self,
        ingest_step: IngestStep,
        transform_step: TransformStep,
        split_step: SplitStep,
        train_step: TrainStep,
        evaluate_step: EvaluateStep,
        register_step: RegisterStep,
    ):
        self._ingest_step = ingest_step
        self._transform_step = transform_step
        self._split_step = split_step
        self._train_step = train_step
        self._evaluate_step = evaluate_step
        self._register_step = register_step

    def run(self):
        dataset = self._ingest_step.ingest()

        transformed_dataset = self._transform_step.transform(dataset)

        train_dataset, test_dataset = self._split_step.split(transformed_dataset)

        train_start = time()

        train_result = self._train_step.train(train_dataset)
        metrics = self._evaluate_step.evaluate(
            train_result.model, test_dataset, train_result.features,
        )

        train_time = time() - train_start

        # TODO: REWRITE IT
        analytic_start = time()

        raw_column_mapping = ColumnMapping(
            target=config.target_col,
            id=config.id_col_name,
        )
        raw_dataset_report = DatasetMetricsReport(
            Preset(dataset.columns.tolist()),
        ).generate(dataset, raw_column_mapping)

        selected_dataset = transformed_dataset[train_result.features + [config.target_col]]
        transformed_column_mapping = ColumnMapping(
            target=config.target_col,
            id=config.id_col_name,
        )
        transformed_dataset_report = DatasetMetricsReport(
            Preset(
                selected_dataset.columns.tolist(),
            ),
        ).generate(selected_dataset, transformed_column_mapping)

        dataset_test_suite = TestSuite(tests=[
            DataQualityTestPreset(),
        ])
        dataset_test_suite.run(
            current_data=selected_dataset,
            reference_data=None,
            # column_mapping=transformed_column_mapping
        )

        analytic_time = time() - analytic_start

        self._register_step.register(
            model=train_result.model,
            features=train_result.features,
            hyperparameters=train_result.hyperparameters,
            metrics=metrics,
            raw_dataset_report=raw_dataset_report,
            transformed_dataset_report=transformed_dataset_report,
            dataset_test_suite=dataset_test_suite,
            analytic_time=analytic_time,
            train_time=train_time,
        )


if __name__ == '__main__':
    args = MLProjectArgs()
    config = MLProjectConfig.from_json(args.config_file)
    project = MLProject(
        ingest_step=IngestStep(
            data_location=config.data_location,
            storage_options=config.storage_options,
            id_col=config.id_col_name,
        ),
        transform_step=TransformStep(
            id_col_name=config.id_col_name,
            target_col=config.target_col,
            label_map=config.label_map,
            label_placeholder=config.label_placeholder,
        ),
        split_step=SplitStep(
            test_size=config.test_size,
        ),
        train_step=TrainStep(
            default_params=config.default_params,
            selection_params=config.selection_params,
            grid_params=config.grid_params,
            target_col=config.target_col,
        ),
        evaluate_step=EvaluateStep(
            target_col=config.target_col,
            metrics=config.metrics,
        ),
        register_step=RegisterStep(
            model_name=config.model_name,
            allow_set_alias=config.allow_set_alias,
            alias=config.alias,
            project_config=config,
        ),
    )
    project.run()
