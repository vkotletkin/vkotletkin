from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class MLProjectArgs(BaseSettings):

    model_config = SettingsConfigDict(cli_parse_args=True, cli_prog_name='MLproject')

    config_file: Path = Field(
        default=Path('conf/config.json'),
        description="""
        Path to file contains mlproject configuration
        """,
    )
