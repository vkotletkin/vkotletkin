from collections.abc import Iterable
from typing import Any

import pandas as pd
from evidently import ColumnMapping
from evidently.metric_preset.metric_preset import AnyMetric, MetricPreset
from evidently.metrics import (
    ColumnCorrelationsMetric,
    ColumnDistributionMetric,
    ColumnQuantileMetric,
    ColumnSummaryMetric,
    DatasetMissingValuesMetric,
    DatasetSummaryMetric,
)
from evidently.metrics.base_metric import generate_column_metrics
from evidently.report import Report
from evidently.utils.data_preprocessing import DataDefinition

QUANTILE_LIST = (0.1, 0.25, 0.5, 0.75, 0.9)


class Preset(MetricPreset):
    class Config:
        type_alias = 'evidently:metric_preset:Preset'

    columns: list[str]

    def __init__(self, columns: list[str]):
        self.columns = columns
        super().__init__()

    def generate_metrics(
        self, data_definition: DataDefinition, additional_data: dict[str, Any] | None,
    ) -> list[AnyMetric]:
        metrics = [
            DatasetSummaryMetric(),
            generate_column_metrics(
                ColumnSummaryMetric,
                columns=self.columns,
                skip_id_column=True,
            ),
            generate_column_metrics(
                ColumnDistributionMetric,
                columns=self.columns,
                skip_id_column=True,
            ),
            generate_column_metrics(
                ColumnCorrelationsMetric,
                columns=self.columns,
                skip_id_column=True,
            ),
            DatasetMissingValuesMetric(),
        ]
        # TODO: add column mapping for using quantile with categorical features
        # metrics.extend(self._generate_column_quantile_metric(QUANTILE_LIST))

        return metrics

    def _generate_column_quantile_metric(
        self, quantile_list: Iterable[float],
    ) -> list[AnyMetric]:
        return [
            generate_column_metrics(
                ColumnQuantileMetric,
                columns=self.columns,
                skip_id_column=True,
                parameters={'quantile': quantile},
            ) for quantile in quantile_list
        ]


class DatasetMetricsReport:

    def __init__(self, preset: MetricPreset):
        self._preset = preset

    def generate(
        self, dataset: pd.DataFrame, column_mapping: ColumnMapping,
    ) -> Report:
        report = Report(metrics=[self._preset])
        report.run(current_data=dataset, reference_data=None, column_mapping=column_mapping)
        return report
