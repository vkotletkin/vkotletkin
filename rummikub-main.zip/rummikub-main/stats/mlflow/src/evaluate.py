import pandas as pd
from catboost import CatBoostClassifier, Pool


class EvaluateStep:

    def __init__(self, target_col: str, metrics: list[str]):
        self._target_col = target_col
        self._metrics = metrics

    def evaluate(
        self,
        model: CatBoostClassifier,
        dataset: pd.DataFrame,
        features: list[str],
    ) -> dict[str, float]:
        pool = Pool(dataset[features], dataset[self._target_col])
        metrics_result = model.eval_metrics(pool, self._metrics)
        return {name: metric[-1] for name, metric in metrics_result.items()}
