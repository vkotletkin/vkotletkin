from copy import deepcopy
from dataclasses import dataclass
from typing import Any

import pandas as pd
from catboost import CatBoostClassifier, Pool


@dataclass
class TrainResult:
    model: CatBoostClassifier
    features: list[str]
    hyperparameters: dict[str, Any]


class TrainStep:

    def __init__(
        self,
        default_params: dict[str, Any],
        selection_params: dict[str, Any],
        grid_params: dict[str, Any],
        target_col: str,
    ):
        self._default_params = default_params
        self._selection_params = selection_params
        self._grid_params = grid_params
        self._target_col = target_col

    def train(self, dataset: pd.DataFrame) -> TrainResult:
        model = CatBoostClassifier(**self._default_params)
        selected_features = self._select_features(model, dataset)
        best_params = self._grid_search(model, dataset, selected_features)
        return TrainResult(
            model=model,
            features=selected_features,
            hyperparameters=best_params,
        )

    def _select_features(
        self, model: CatBoostClassifier, dataset: pd.DataFrame,
    ) -> list[str]:
        pool = self._create_pool(dataset)
        selected_features_kwargs = deepcopy(self._selection_params)
        if 'features_for_select' not in selected_features_kwargs:
            selected_features_kwargs['features_for_select'] = pool.get_feature_names()
        select_features_result = model.select_features(pool, **selected_features_kwargs)
        return select_features_result['selected_features_names']

    def _grid_search(
        self,
        model: CatBoostClassifier,
        dataset: pd.DataFrame,
        selected_features: list[str],
    ) -> dict[str, Any]:
        grid_search_result = model.grid_search(
            X=self._create_pool(dataset, selected_features),
            param_grid=self._grid_params,
        )
        return grid_search_result['params']

    def _create_pool(
        self, dataset: pd.DataFrame, features: list[str] | None = None,
    ) -> Pool:
        target_col = self._target_col

        if features is None:
            features = self._selection_params.get(
                'features_for_select',
                pd.Series([col for col in dataset.columns.values if col != target_col]),
            )

        return Pool(dataset[features], dataset[target_col])
