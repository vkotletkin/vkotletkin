import pandas as pd
from sklearn.model_selection import train_test_split


class SplitStep:

    def __init__(self, test_size: float):
        self._test_size = test_size

    def split(self, dataset: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
        return train_test_split(dataset, test_size=self._test_size)
