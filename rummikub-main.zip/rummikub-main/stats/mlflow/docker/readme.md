# Build base mlproject docker image

```bash
export NEXUS_USER=... \
	NEXUS_PASSWORD=... \
	NEXUS_DOCKER_REGISTRY=...

docker login -u ${NEXUS_USER} -p ${NEXUS_PASSWORD} ${NEXUS_DOCKER_REGISTRY}
docker pull ${NEXUS_DOCKER_REGISTRY}/docker-private/bentoml-base/python:3.10-slim
docker tag ${NEXUS_DOCKER_REGISTRY}/docker-private/bentoml-base/python:3.10-slim python:3.10-slim

docker build --build-arg BASE_IMAGE=python:3.10-slim -t ${NEXUS_DOCKER_REGISTRY}/mlproject-stats:python3.10 .

docker push ${NEXUS_DOCKER_REGISTRY}/mlproject-stats:python3.10
```
