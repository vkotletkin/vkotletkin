### Подготовка данных 

Перед обучением модели вы должны подготовить датасет. В примере представлена загрузка данных из s3, но вы можете поменять расположение через аргумент `--data-location`.

### Подготовка окружения

```bash
export NEXUS_USER=... \
	NEXUS_PASSWORD=... \
	NEXUS_DOCKER_REGISTRY=...

docker login -u ${NEXUS_USER} -p ${NEXUS_PASSWORD} ${NEXUS_DOCKER_REGISTRY}

docker pull ${NEXUS_DOCKER_REGISTRY}/mlproject-stats:python3.10

docker tag ${NEXUS_DOCKER_REGISTRY}/mlproject-stats:python3.10 mlproject-stats:python3.10
```

### Запуск обучения модели

```bash
export MLFLOW_TRACKING_URI=... \
	AWS_ACCESS_KEY_ID=... \
	AWS_SECRET_ACCESS_KEY=... \
	MLFLOW_S3_ENDPOINT_URL=... \
	MLFLOW_EXPERIMENT_NAME=GenderPrediction
mlflow run . -P config_file conf/config.json
```
