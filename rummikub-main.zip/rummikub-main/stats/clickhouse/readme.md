### Intro

Эта инструкция предназначена для настройки расчёта статистик биллинга "руками". Позже это может быть автоматизировано и встроено в etl, но пока не везде есть такая возможность. 

### Preparation

Для начала работы требуется установить `clickhouse-client`. 

Установите хост-порт для открытый для tcp соединения. 

```bash
export CLICK_HOST="my.example.host" CLICK_PORT="9000"
```

Утсановите переменные окружения для настройки подключения к S3.

```bash
export S3_ENDPOINT_URL="http://<s3_host>:<s3_port>/<bucket>" S3_ACCESS_KEY_ID="..." S3_SECRET_ACCESS_KEY="..."
```

Если ваш кластер называется не "bic_cluster", то поменяйте названия в sql-файлах с созданием таблиц.

### Populate

Перед расчётом статистик требуется создать таблицу (или представление) нужного формата.

Создадим таблицу. Название таблицы и базы можно поменять в `conf/session_table_params.txt`. Таблица (или представление) должна совпадать со схемой указанной в файле `sql/create_sessions_table.sql` и содержать все входящие и исходящие сессии для каждого пользователя. Это означает, что на каждую сессию в таблице будет две записи. В одной сессия будет представлена как исходящая `is_outgoing=true` и `msisdn_left` будет означать абонента совершающего вызов, а в другой сессия будет представлена как входящая `is_outgoing=false` и `msisdn_left` поменяется местами с `msisdn_right` относительно первой записи.  
  
Определите путь к файлу с таблицей в S3.

```bash
export PATH_TO_SESSIONS_CSV_FILE="..." 
```

После этого заполним таблицу. Мы привёдем пример создания таблицы из csv-файла с колонками `DATE_TIME, DURATION, TEL_FROM_HASH, TEL_TO_HASH, DIRECTION` и разделителем `\t` расположенного в minio, но вы можете изменить источник данных на локальную файловую систему, другую таблицу и т.д.

```bash
clickhouse-client \
    --host $CLICK_HOST \
    --port $CLICK_PORT \
    --queries-file sql/create_sessions_table.sql sql/populate_from_s3.sql \
    --param_sessions_db="gallery_1_pf_store_billing" \
    --param_sessions_table="data_sessions_v2" \
    --param_s3_resource="${S3_ENDPOINT_URL}/${PATH_TO_SESSIONS_CSV_FILE}" \
    --param_access_key_id=$S3_ACCESS_KEY_ID \
    --param_secret_access_key=$S3_SECRET_ACCESS_KEY \
    --param_file_format="TabSeparatedWithNames"
```


### Calc stats

Если таблица с сессиями уже создана, можно приступать к рассчёту статистических признаков абонентов. Названия таблиц можно контролировать через параметры (подробнее в sql-исходниках). 

```bash
clickhouse-client \
    --host $CLICK_HOST \
    --port $CLICK_PORT \
    --queries-file sql/call_stats.sql sql/in_out_session_ratio_stats.sql sql/interluctor_count_by_day.sql sql/interluctor_count_by_week.sql sql/interluctor_count_by_month.sql sql/session_by_day.sql sql/interluctor_count_by_month.sql sql/session_by_week.sql sql/session_by_month.sql sql/one_interluctor_session_count.sql sql/foreign_country_by_day.sql sql/foreign_country_by_week.sql sql/foreign_country_by_month.sql sql/bs_by_day.sql sql/bs_by_week.sql sql/bs_by_month.sql sql/one_bs_by_day.sql sql/one_bs_by_week.sql sql/one_bs_by_month.sql sql/create_all_stats.sql \
    --param_sessions_db="gallery_1_pf_store_billing" \
    --param_sessions_table="data_sessions_v2" \
    --param_stats_db="gallery_1_pf_store_billing_stat" \
    --param_call_stats_table="data_call_stats_v1" \
    --param_in_out_ratio_stats_table="data_in_out_call_ratio_stats_v1" \
    --param_interluctor_count_by_day_table="data_interluctor_count_by_day_stats_v1" \
    --param_interluctor_count_by_month_table="data_interluctor_count_by_month_stats_v1" \
    --param_interluctor_count_by_week_table="data_interluctor_count_by_week_stats_v1" \
    --param_session_by_day_table="data_session_count_by_day_stats_v1" \
    --param_session_by_month_table="data_session_count_by_month_stats_v1" \
    --param_session_by_week_table="data_session_count_by_week_stats_v1" \
    --param_one_interluctor_count_table="data_one_interluctor_count_stats_v1" \
    --param_foreign_contry_by_day_table="foreign_contry_by_day_v2" \
    --param_foreign_contry_by_week_table="foreign_contry_by_week_v2" \
    --param_foreign_contry_by_month_table="foreign_contry_by_month_v2" \
    --param_base_stations_by_day_table="base_stations_by_day_v2" \
    --param_base_stations_by_week_table="base_stations_by_week_v2" \
    --param_base_stations_by_month_table="base_stations_by_month_v2" \
    --param_sessions_from_one_base_station_by_day_table="sessions_from_one_base_station_by_day_v2" \
    --param_sessions_from_one_base_station_by_week_table="sessions_from_one_base_station_by_week_v2" \
    --param_sessions_from_one_base_station_by_month_table="sessions_from_one_base_station_by_month_v2" \
    --param_all_stats_mv_table_name="all_stats_table_v2"
```

### Create dataset 

После того, как мы расчитали признаки, можно подготовить датасет для обучения модели. Мы рассмотрим создание датасета из расчитанных в кликхаусе статистик и csv-файла с колонками `SEX, msisdn_hash` и разделителем `\t` расположенного в minio. 


Укажите путь к файлу с разметкой и путь к итоговому датасету. 

```bash
export PATH_TO_LABELS_CSV_FILE="..." PATH_TO_DATASET_CSV_FILE="..."
```

Укажите колонку файла `$PATH_TO_LABELS_CSV_FILE` в которой содержится метка класса.

```bash
export LABEL_COL="..."
```

Укажите название колонки с идентификатором по которому будет производиться сопоставление с таблицей признаков.

```bash
export ID_COL="..."
```

Выполните скрипт.

```bash
clickhouse-client \
    --host $CLICK_HOST \
    --port $CLICK_PORT \
    --queries-file sql/create_dataset.sql \
    --param_s3_target_resource="${S3_ENDPOINT_URL}/${PATH_TO_LABELS_CSV_FILE}" \
    --param_s3_dataset_resource="${S3_ENDPOINT_URL}/${PATH_TO_DATASET_CSV_FILE}" \
    --param_access_key_id=$S3_ACCESS_KEY_ID \
    --param_secret_access_key=$S3_SECRET_ACCESS_KEY \
    --param_target_file_format="TabSeparatedWithNames" \
    --param_dataset_file_format="CSVWithNames" \
    --param_all_stats_mv_table_name="all_stats_table_v2" \
    --param_stats_db="gallery_1_pf_store_billing_stat" \
    --param_target_col=$LABEL_COL \
    --param_target_msisdn=$ID_COL
```

### Batch calculation

Расчёт статистик на больших временных отрезках может быть вычислительно затратной задачей. В таком случае расчёт статистик рекомендуется производить для батчей пользователей. Размер батча зависит от доступных вычислительных мощностей и промежутка времени для которого расчитываются статистики. 
