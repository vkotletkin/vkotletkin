CREATE DATABASE IF NOT EXISTS {stats_db:Identifier} ON CLUSTER 'bic_cluster';

CREATE TABLE IF NOT EXISTS {stats_db:Identifier}.{foreign_contry_by_week_table:Identifier} ON CLUSTER 'bic_cluster' (
    msisdn String,
    quantile_10_foreign_contry_sessions_by_week Float32,
    median_foreign_contry_sessions_by_week Float32,
    quantile_90_foreign_contry_sessions_by_week Float32,
    quantile_10_foreign_contry_output_sessions_by_week Float32,
    median_foreign_contry_output_sessions_by_week Float32,
    quantile_90_foreign_contry_output_sessions_by_week Float32,
    quantile_10_foreign_contry_input_sessions_by_week Float32,
    median_foreign_contry_input_sessions_by_week Float32,
    quantile_90_foreign_contry_input_sessions_by_week Float32,
    quantile_10_foreign_contry_continuous_sessions_by_week Float32,
    median_foreign_contry_continuous_sessions_by_week Float32,
    quantile_90_foreign_contry_continuous_sessions_by_week Float32
) ENGINE = ReplacingMergeTree()
ORDER BY msisdn;

INSERT INTO {stats_db:Identifier}.{foreign_contry_by_week_table:Identifier}
WITH
    foreign_session_count AS (
        WITH daily_sessions AS (
            SELECT
                msisdn_left AS msisdn,
                toStartOfWeek(dt) AS week,
                count() AS session_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            WHERE
                mcc_left != mcc_right AND mcc_left != '' AND mcc_right != ''
            GROUP BY
                msisdn,
                week
        )
        SELECT
            msisdn,
            quantile(0.1)(session_count) AS quantile_10_foreign_contry_sessions_by_week,
            quantile(0.5)(session_count) AS median_foreign_contry_sessions_by_week,
            quantile(0.9)(session_count) AS quantile_90_foreign_contry_sessions_by_week
        FROM
            daily_sessions
        GROUP BY
            msisdn
    ),
    foreign_output_session_count AS (
        WITH daily_output_sessions AS (
            SELECT
                msisdn_left AS msisdn,
                toStartOfWeek(dt) AS week,
                count() AS session_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            WHERE
                mcc_left != mcc_right AND mcc_left != '' AND mcc_right != '' AND is_outgoing == true
            GROUP BY
                msisdn,
                week
        )
        SELECT
            msisdn,
            quantile(0.1)(session_count) AS quantile_10_foreign_contry_output_sessions_by_week,
            quantile(0.5)(session_count) AS median_foreign_contry_output_sessions_by_week,
            quantile(0.9)(session_count) AS quantile_90_foreign_contry_output_sessions_by_week
        FROM
            daily_output_sessions
        GROUP BY
            msisdn
    ),
    foreign_input_session_count AS (
        WITH daily_input_sessions AS (
            SELECT
                msisdn_left AS msisdn,
                toStartOfWeek(dt) AS week,
                count() AS session_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            WHERE
                mcc_left != mcc_right AND mcc_left != '' AND mcc_right != '' AND is_outgoing == false
            GROUP BY
                msisdn,
                week
        )
        SELECT
            msisdn,
            quantile(0.1)(session_count) AS quantile_10_foreign_contry_input_sessions_by_week,
            quantile(0.5)(session_count) AS median_foreign_contry_input_sessions_by_week,
            quantile(0.9)(session_count) AS quantile_90_foreign_contry_input_sessions_by_week
        FROM
            daily_input_sessions
        GROUP BY
            msisdn
    ),
    foreign_continuous_session_count AS (
        WITH daily_continuous_sessions AS (
            SELECT
                msisdn_left AS msisdn,
                toStartOfWeek(dt) AS week,
                count() AS session_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            WHERE
                mcc_left != mcc_right AND mcc_left != '' AND mcc_right != '' AND dur > 0
            GROUP BY
                msisdn,
                week
        )
        SELECT
            msisdn,
            quantile(0.1)(session_count) AS quantile_10_foreign_contry_continuous_sessions_by_week,
            quantile(0.5)(session_count) AS median_foreign_contry_continuous_sessions_by_week,
            quantile(0.9)(session_count) AS quantile_90_foreign_contry_continuous_sessions_by_week
        FROM
            daily_continuous_sessions
        GROUP BY
            msisdn
    )
SELECT t1.msisdn, COLUMNS('[^(msisdn)]')
FROM
    foreign_session_count AS t1
LEFT OUTER JOIN
    foreign_output_session_count AS t2 ON t1.msisdn == t2.msisdn
LEFT OUTER JOIN
    foreign_input_session_count AS t3 ON t1.msisdn == t3.msisdn
LEFT OUTER JOIN
    foreign_continuous_session_count AS t4 ON t1.msisdn == t4.msisdn;
