INSERT INTO {sessions_db:Identifier}.{sessions_table:Identifier}
SELECT * FROM (
    SELECT
        DATE_TIME AS dt,
        DURATION AS dur,
        TEL_FROM_HASH AS msisdn_left,
        TEL_TO_HASH AS msisdn_right,
        MCC_FROM AS mcc_left,
        MCC_TO AS mcc_right,
        CELLID_FROM AS cellid_left,
        CELLID_TO AS cellid_right,
        DIRECTION AS is_outgoing
    FROM s3({s3_resource:String}, {access_key_id:String}, {secret_access_key:String}, {file_format:String})
    WHERE DIRECTION = 1

    UNION ALL

    SELECT
        DATE_TIME AS dt,
        DURATION AS dur,
        TEL_TO_HASH AS msisdn_left,
        TEL_FROM_HASH AS msisdn_right,
        MCC_TO AS mcc_left,
        MCC_FROM AS mcc_right,
        CELLID_TO AS cellid_left,
        CELLID_FROM AS cellid_right,
        DIRECTION * 0 AS is_outgoing
    FROM s3({s3_resource:String}, {access_key_id:String}, {secret_access_key:String}, {file_format:String})
    WHERE DIRECTION = 1

    UNION ALL

    SELECT
        DATE_TIME AS dt,
        DURATION AS dur,
        TEL_FROM_HASH AS msisdn_left,
        TEL_TO_HASH AS msisdn_right,
        MCC_FROM AS mcc_left,
        MCC_TO AS mcc_right,
        CELLID_FROM AS cellid_left,
        CELLID_TO AS cellid_right,
        DIRECTION AS is_outgoing
    FROM s3({s3_resource:String}, {access_key_id:String}, {secret_access_key:String}, {file_format:String})
    WHERE DIRECTION = 0

    UNION ALL

    SELECT
        DATE_TIME AS dt,
        DURATION AS dur,
        TEL_TO_HASH AS msisdn_left,
        TEL_FROM_HASH AS msisdn_right,
        MCC_TO AS mcc_left,
        MCC_FROM AS mcc_right,
        CELLID_TO AS cellid_left,
        CELLID_FROM AS cellid_right,
        DIRECTION + 1 AS is_outgoing
    FROM s3({s3_resource:String}, {access_key_id:String}, {secret_access_key:String}, {file_format:String})
    WHERE DIRECTION = 0
);
