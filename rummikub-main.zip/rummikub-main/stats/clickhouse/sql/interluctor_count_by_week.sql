CREATE DATABASE IF NOT EXISTS {stats_db:Identifier} ON CLUSTER 'bic_cluster';

CREATE TABLE IF NOT EXISTS {stats_db:Identifier}.{interluctor_count_by_week_table:Identifier} ON CLUSTER 'bic_cluster' (
    msisdn String,
    quantile_10_interlocutor_count_by_week Float32,
    median_interlocutor_count_by_week Float32,
    quantile_90_interlocutor_count_by_week Float32,
    quantile_10_output_interlocutor_count_by_week Float32,
    median_output_interlocutor_count_by_week Float32,
    quantile_90_output_interlocutor_count_by_week Float32,
    quantile_10_input_interlocutor_count_by_week Float32,
    median_input_interlocutor_count_by_week Float32,
    quantile_90_input_interlocutor_count_by_week Float32,
    quantile_10_continuous_interlocutor_count_by_week Float32,
    median_continuous_interlocutor_count_by_week Float32,
    quantile_90_continuous_interlocutor_count_by_week Float32,
    quantile_10_continuous_output_interlocutor_count_by_week Float32,
    median_continuous_output_interlocutor_count_by_week Float32,
    quantile_90_continuous_output_interlocutor_count_by_week Float32,
    quantile_10_continuous_input_interlocutor_count_by_week Float32,
    median_continuous_input_interlocutor_count_by_week Float32,
    quantile_90_continuous_input_interlocutor_count_by_week Float32
) ENGINE = ReplacingMergeTree()
ORDER BY msisdn;

INSERT INTO {stats_db:Identifier}.{interluctor_count_by_week_table:Identifier}
WITH
    count_interluctor_by_week AS (
        WITH interlocutor_counts_by_week AS (
            SELECT
                msisdn_left AS msisdn,
                toStartOfWeek(dt) AS week,
                count(DISTINCT msisdn_right) AS interlocutor_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            GROUP BY
                msisdn_left,
                week
        )
        SELECT
            msisdn,
            quantile(0.1)(interlocutor_count) AS quantile_10_interlocutor_count_by_week,
            quantile(0.5)(interlocutor_count) AS median_interlocutor_count_by_week,
            quantile(0.9)(interlocutor_count) AS quantile_90_interlocutor_count_by_week
        FROM
            interlocutor_counts_by_week
        GROUP BY
            msisdn
    ),
    count_output_interluctor_by_week AS (
        WITH output_interlocutor_counts_by_week AS (
            SELECT
                msisdn_left AS msisdn,
                toStartOfWeek(dt) AS week,
                count(DISTINCT msisdn_right) AS interlocutor_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            WHERE
                is_outgoing == true
            GROUP BY
                msisdn_left,
                week
        )
        SELECT
            msisdn,
            quantile(0.1)(interlocutor_count) AS quantile_10_output_interlocutor_count_by_week,
            quantile(0.5)(interlocutor_count) AS median_output_interlocutor_count_by_week,
            quantile(0.9)(interlocutor_count) AS quantile_90_output_interlocutor_count_by_week
        FROM
            output_interlocutor_counts_by_week
        GROUP BY
            msisdn
    ),
    count_input_interluctor_by_week AS (
        WITH input_interlocutor_counts_by_week AS (
            SELECT
                msisdn_left AS msisdn,
                toStartOfWeek(dt) AS week,
                count(DISTINCT msisdn_right) AS interlocutor_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            WHERE
                is_outgoing == false
            GROUP BY
                msisdn_left,
                week
        )
        SELECT
            msisdn,
            quantile(0.1)(interlocutor_count) AS quantile_10_input_interlocutor_count_by_week,
            quantile(0.5)(interlocutor_count) AS median_input_interlocutor_count_by_week,
            quantile(0.9)(interlocutor_count) AS quantile_90_input_interlocutor_count_by_week
        FROM
            input_interlocutor_counts_by_week
        GROUP BY
            msisdn
    ),
    count_continuous_interluctor_by_week AS (
        WITH continuous_interlocutor_counts_by_week AS (
            SELECT
                msisdn_left AS msisdn,
                toStartOfWeek(dt) AS week,
                count(DISTINCT msisdn_right) AS interlocutor_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            WHERE
                dur > 0
            GROUP BY
                msisdn_left,
                week
        )
        SELECT
            msisdn,
            quantile(0.1)(interlocutor_count) AS quantile_10_continuous_interlocutor_count_by_week,
            quantile(0.5)(interlocutor_count) AS median_continuous_interlocutor_count_by_week,
            quantile(0.9)(interlocutor_count) AS quantile_90_continuous_interlocutor_count_by_week
        FROM
            continuous_interlocutor_counts_by_week
        GROUP BY
            msisdn
    ),
    count_continuous_output_interluctor_by_week AS (
        WITH continuous_output_interlocutor_counts_by_week AS (
            SELECT
                msisdn_left AS msisdn,
                toStartOfWeek(dt) AS week,
                count(DISTINCT msisdn_right) AS interlocutor_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            WHERE
                dur > 0 and is_outgoing == true
            GROUP BY
                msisdn_left,
                week
        )
        SELECT
            msisdn,
            quantile(0.1)(interlocutor_count) AS quantile_10_continuous_output_interlocutor_count_by_week,
            quantile(0.5)(interlocutor_count) AS median_continuous_output_interlocutor_count_by_week,
            quantile(0.9)(interlocutor_count) AS quantile_90_continuous_output_interlocutor_count_by_week
        FROM
            continuous_output_interlocutor_counts_by_week
        GROUP BY
            msisdn
    ),
    count_continuous_input_interluctor_by_week AS (
        WITH continuous_input_interlocutor_counts_by_week AS (
            SELECT
                msisdn_left AS msisdn,
                toStartOfWeek(dt) AS week,
                count(DISTINCT msisdn_right) AS interlocutor_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            WHERE
                dur > 0 and is_outgoing == false
            GROUP BY
                msisdn_left,
                week
        )
        SELECT
            msisdn,
            quantile(0.1)(interlocutor_count) AS quantile_10_continuous_input_interlocutor_count_by_week,
            quantile(0.5)(interlocutor_count) AS median_continuous_input_interlocutor_count_by_week,
            quantile(0.9)(interlocutor_count) AS quantile_90_continuous_input_interlocutor_count_by_week
        FROM
            continuous_input_interlocutor_counts_by_week
        GROUP BY
            msisdn
    )
SELECT count_interluctor_by_week.msisdn as msisdn, COLUMNS('[^(msisdn)]')
FROM
    count_interluctor_by_week AS t1
LEFT OUTER JOIN
    count_output_interluctor_by_week AS t2 ON t1.msisdn = t2.msisdn
LEFT OUTER JOIN
    count_input_interluctor_by_week AS t3 ON t1.msisdn = t3.msisdn
LEFT OUTER JOIN
    count_continuous_interluctor_by_week AS t4 ON t1.msisdn = t4.msisdn
LEFT OUTER JOIN
    count_continuous_output_interluctor_by_week AS t5 ON t1.msisdn = t5.msisdn
LEFT OUTER JOIN
    count_continuous_input_interluctor_by_week AS t6 ON t1.msisdn = t6.msisdn;