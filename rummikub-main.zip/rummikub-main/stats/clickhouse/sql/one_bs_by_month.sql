CREATE DATABASE IF NOT EXISTS {stats_db:Identifier} ON CLUSTER 'bic_cluster';

CREATE TABLE IF NOT EXISTS {stats_db:Identifier}.{sessions_from_one_base_station_by_month_table:Identifier} ON CLUSTER 'bic_cluster' (
    msisdn String,
    quantile_10_sessions_from_one_base_station_per_month Float32,
    median_sessions_from_one_base_station_per_month Float32,
    quantile_90_sessions_from_one_base_station_per_month Float32,
    quantile_10_output_sessions_from_one_base_station_per_month Float32,
    median_output_sessions_from_one_base_station_per_month Float32,
    quantile_90_output_sessions_from_one_base_station_per_month Float32,
    quantile_10_input_sessions_from_one_base_station_per_month Float32,
    median_input_sessions_from_one_base_station_per_month Float32,
    quantile_90_input_sessions_from_one_base_station_per_month Float32
) ENGINE = ReplacingMergeTree()
ORDER BY msisdn;

INSERT INTO {stats_db:Identifier}.{sessions_from_one_base_station_by_month_table:Identifier}
WITH
    sessions_from_one_base_station_count AS (
        WITH daily_sessions_from_one_base_station AS (
            SELECT
                msisdn_left AS msisdn,
                toStartOfMonth(dt) AS month,
                cellid_left AS base_station,
                count() AS session_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            GROUP BY
                msisdn_left,
                month,
                base_station
        )
        SELECT
            msisdn,
            quantile(0.1)(session_count) AS quantile_10_sessions_from_one_base_station_per_month,
            quantile(0.5)(session_count) AS median_sessions_from_one_base_station_per_month,
            quantile(0.9)(session_count) AS quantile_90_sessions_from_one_base_station_per_month
        FROM
            daily_sessions_from_one_base_station
        GROUP BY
            msisdn
    ),
    output_sessions_from_one_base_station_count AS (
        WITH daily_output_sessions_from_one_base_station AS (
            SELECT
                msisdn_left AS msisdn,
                toStartOfMonth(dt) AS month,
                cellid_left AS base_station,
                count() AS session_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            WHERE
                is_outgoing == true
            GROUP BY
                msisdn_left,
                month,
                base_station
        )
        SELECT
            msisdn,
            quantile(0.1)(session_count) AS quantile_10_output_sessions_from_one_base_station_per_month,
            quantile(0.5)(session_count) AS median_output_sessions_from_one_base_station_per_month,
            quantile(0.9)(session_count) AS quantile_90_output_sessions_from_one_base_station_per_month
        FROM
            daily_output_sessions_from_one_base_station
        GROUP BY
            msisdn
    ),
    input_sessions_from_one_base_station_count AS (
        WITH daily_input_sessions_from_one_base_station AS (
            SELECT
                msisdn_left AS msisdn,
                toStartOfMonth(dt) AS month,
                cellid_left AS base_station,
                count() AS session_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            WHERE
                is_outgoing == false
            GROUP BY
                msisdn_left,
                month,
                base_station
        )
        SELECT
            msisdn,
            quantile(0.1)(session_count) AS quantile_10_input_sessions_from_one_base_station_per_month,
            quantile(0.5)(session_count) AS median_input_sessions_from_one_base_station_per_month,
            quantile(0.9)(session_count) AS quantile_90_input_sessions_from_one_base_station_per_month
        FROM
            daily_input_sessions_from_one_base_station
        GROUP BY
            msisdn
    )
SELECT sessions_from_one_base_station_count.msisdn as msisdn, COLUMNS('[^(msisdn)]')
FROM
    sessions_from_one_base_station_count AS t1
LEFT OUTER JOIN
    output_sessions_from_one_base_station_count AS t2 ON t1.msisdn = t2.msisdn
LEFT OUTER JOIN
    input_sessions_from_one_base_station_count AS t3 ON t1.msisdn = t3.msisdn;