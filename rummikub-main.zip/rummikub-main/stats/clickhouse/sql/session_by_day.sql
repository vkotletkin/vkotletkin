CREATE DATABASE IF NOT EXISTS {stats_db:Identifier} ON CLUSTER 'bic_cluster';

CREATE TABLE IF NOT EXISTS {stats_db:Identifier}.{session_by_day_table:Identifier} ON CLUSTER 'bic_cluster' (
    msisdn String,
    quantile_10_sessions_per_day Float32,
    median_sessions_per_day Float32,
    quantile_90_sessions_per_day Float32,
    quantile_10_output_sessions_per_day Float32,
    median_output_sessions_per_day Float32,
    quantile_90_output_sessions_per_day Float32,
    quantile_10_input_sessions_per_day Float32,
    median_input_sessions_per_day Float32,
    quantile_90_input_sessions_per_day Float32,
    quantile_10_continuous_sessions_per_day Float32,
    median_continuous_sessions_per_day Float32,
    quantile_90_continuous_sessions_per_day Float32,
    quantile_10_continuous_output_sessions_per_day Float32,
    median_continuous_output_sessions_per_day Float32,
    quantile_90_continuous_output_sessions_per_day Float32,
    quantile_10_continuous_input_sessions_per_day Float32,
    median_continuous_input_sessions_per_day Float32,
    quantile_90_continuous_input_sessions_per_day Float32
) ENGINE = ReplacingMergeTree()
ORDER BY msisdn;

INSERT INTO {stats_db:Identifier}.{session_by_day_table:Identifier}
WITH
    session_count AS (
        WITH daily_sessions AS (
            SELECT
                msisdn_left AS msisdn,
                toDate(dt) AS day,
                count() AS session_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            GROUP BY
                msisdn_left,
                day
        )
        SELECT
            msisdn,
            quantile(0.1)(session_count) AS quantile_10_sessions_per_day,
            quantile(0.5)(session_count) AS median_sessions_per_day,
            quantile(0.9)(session_count) AS quantile_90_sessions_per_day
        FROM
            daily_sessions
        GROUP BY
            msisdn
    ),
    output_session_count AS (
        WITH daily_output_sessions AS (
            SELECT
                msisdn_left AS msisdn,
                toDate(dt) AS day,
                count() AS session_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            WHERE
                is_outgoing == true
            GROUP BY
                msisdn_left,
                day
        )
        SELECT
            msisdn,
            quantile(0.1)(session_count) AS quantile_10_output_sessions_per_day,
            quantile(0.5)(session_count) AS median_output_sessions_per_day,
            quantile(0.9)(session_count) AS quantile_90_output_sessions_per_day
        FROM
            daily_output_sessions
        GROUP BY
            msisdn
    ),
    input_session_count AS (
        WITH daily_input_sessions AS (
            SELECT
                msisdn_left AS msisdn,
                toDate(dt) AS day,
                count() AS session_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            WHERE
                is_outgoing == false
            GROUP BY
                msisdn_left,
                day
        )
        SELECT
            msisdn,
            quantile(0.1)(session_count) AS quantile_10_input_sessions_per_day,
            quantile(0.5)(session_count) AS median_input_sessions_per_day,
            quantile(0.9)(session_count) AS quantile_90_input_sessions_per_day
        FROM
            daily_input_sessions
        GROUP BY
            msisdn
    ),
    continuous_session_count AS (
        WITH daily_continuous_sessions AS (
            SELECT
                msisdn_left AS msisdn,
                toDate(dt) AS day,
                count() AS session_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            WHERE
                dur > 0
            GROUP BY
                msisdn_left,
                day
        )
        SELECT
            msisdn,
            quantile(0.1)(session_count) AS quantile_10_continuous_sessions_per_day,
            quantile(0.5)(session_count) AS median_continuous_sessions_per_day,
            quantile(0.9)(session_count) AS quantile_90_continuous_sessions_per_day
        FROM
            daily_continuous_sessions
        GROUP BY
            msisdn
    ),
    continuous_output_session_count AS (
        WITH daily_continuous_output_sessions AS (
            SELECT
                msisdn_left AS msisdn,
                toDate(dt) AS day,
                count() AS session_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            WHERE
                dur > 0 and is_outgoing == true
            GROUP BY
                msisdn_left,
                day
        )
        SELECT
            msisdn,
            quantile(0.1)(session_count) AS quantile_10_continuous_output_sessions_per_day,
            quantile(0.5)(session_count) AS median_continuous_output_sessions_per_day,
            quantile(0.9)(session_count) AS quantile_90_continuous_output_sessions_per_day
        FROM
            daily_continuous_output_sessions
        GROUP BY
            msisdn
    ),
    continuous_input_session_count AS (
        WITH daily_continuous_input_sessions AS (
            SELECT
                msisdn_left AS msisdn,
                toDate(dt) AS day,
                count() AS session_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            WHERE
                dur > 0 and is_outgoing == true
            GROUP BY
                msisdn_left,
                day
        )
        SELECT
            msisdn,
            quantile(0.1)(session_count) AS quantile_10_continuous_input_sessions_per_day,
            quantile(0.5)(session_count) AS median_continuous_input_sessions_per_day,
            quantile(0.9)(session_count) AS quantile_90_continuous_input_sessions_per_day
        FROM
            daily_continuous_input_sessions
        GROUP BY
            msisdn
    )
SELECT session_count.msisdn as msisdn, COLUMNS('[^(msisdn)]')
FROM
    session_count AS t1
LEFT OUTER JOIN
    output_session_count AS t2 ON t1.msisdn = t2.msisdn
LEFT OUTER JOIN
    input_session_count AS t3 ON t1.msisdn = t3.msisdn
LEFT OUTER JOIN
    continuous_session_count AS t4 ON t1.msisdn = t4.msisdn
LEFT OUTER JOIN
    continuous_output_session_count AS t5 ON t1.msisdn = t5.msisdn
LEFT OUTER JOIN
    continuous_input_session_count AS t6 ON t1.msisdn = t6.msisdn;