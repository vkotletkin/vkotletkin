CREATE DATABASE IF NOT EXISTS {stats_db:Identifier} ON CLUSTER 'bic_cluster';

CREATE TABLE IF NOT EXISTS {stats_db:Identifier}.{call_stats_table:Identifier} ON CLUSTER 'bic_cluster' (
    msisdn String,
    median_call_duration Float32,
    quantile_90_call_duration Float32,
    quantile_10_call_duration Float32,
    percentage_long_calls Float32,
    percentage_short_calls Float32,
    percentage_average_calls Float32,
    percentage_sessions_between_00_04 Float32,
    percentage_sessions_between_04_08 Float32,
    percentage_sessions_between_08_12 Float32,
    percentage_sessions_between_12_16 Float32,
    percentage_sessions_between_16_20 Float32,
    percentage_sessions_between_20_24 Float32,
    percentage_sessions_on_weekday Float32,
    percentage_sessions_on_weekend Float32,
    percentage_sessions_on_monday Float32,
    percentage_sessions_on_tuesday Float32,
    percentage_sessions_on_wednesday Float32,
    percentage_sessions_on_thursday Float32,
    percentage_sessions_on_friday Float32,
    percentage_sessions_on_saturday Float32,
    percentage_sessions_on_sunday Float32,
    median_output_call_duration Float32,
    quantile_90_output_call_duration Float32,
    quantile_10_output_call_duration Float32,
    percentage_long_output_calls Float32,
    percentage_short_output_calls Float32,
    percentage_average_output_calls Float32,
    percentage_output_sessions_between_00_04 Float32,
    percentage_output_sessions_between_04_08 Float32,
    percentage_output_sessions_between_08_12 Float32,
    percentage_output_sessions_between_12_16 Float32,
    percentage_output_sessions_between_16_20 Float32,
    percentage_output_sessions_between_20_24 Float32,
    percentage_output_sessions_on_weekday Float32,
    percentage_output_sessions_on_weekend Float32,
    percentage_output_sessions_on_monday Float32,
    percentage_output_sessions_on_tuesday Float32,
    percentage_output_sessions_on_wednesday Float32,
    percentage_output_sessions_on_thursday Float32,
    percentage_output_sessions_on_friday Float32,
    percentage_output_sessions_on_saturday Float32,
    percentage_output_sessions_on_sunday Float32,
    median_input_call_duration Float32,
    quantile_90_input_call_duration Float32,
    quantile_10_input_call_duration Float32,
    percentage_long_input_calls Float32,
    percentage_short_input_calls Float32,
    percentage_average_input_calls Float32,
    percentage_input_sessions_between_00_04 Float32,
    percentage_input_sessions_between_04_08 Float32,
    percentage_input_sessions_between_08_12 Float32,
    percentage_input_sessions_between_12_16 Float32,
    percentage_input_sessions_between_16_20 Float32,
    percentage_input_sessions_between_20_24 Float32,
    percentage_input_sessions_on_weekday Float32,
    percentage_input_sessions_on_weekend Float32,
    percentage_input_sessions_on_monday Float32,
    percentage_input_sessions_on_tuesday Float32,
    percentage_input_sessions_on_wednesday Float32,
    percentage_input_sessions_on_thursday Float32,
    percentage_input_sessions_on_friday Float32,
    percentage_input_sessions_on_saturday Float32,
    percentage_input_sessions_on_sunday Float32,
    median_continuous_call_duration Float32,
    quantile_90_continuous_call_duration Float32,
    quantile_10_continuous_call_duration Float32,
    percentage_long_continuous_calls Float32,
    percentage_short_continuous_calls Float32,
    percentage_average_continuous_calls Float32,
    percentage_continuous_sessions_between_00_04 Float32,
    percentage_continuous_sessions_between_04_08 Float32,
    percentage_continuous_sessions_between_08_12 Float32,
    percentage_continuous_sessions_between_12_16 Float32,
    percentage_continuous_sessions_between_16_20 Float32,
    percentage_continuous_sessions_between_20_24 Float32,
    percentage_continuous_sessions_on_weekday Float32,
    percentage_continuous_sessions_on_weekend Float32,
    percentage_continuous_sessions_on_monday Float32,
    percentage_continuous_sessions_on_tuesday Float32,
    percentage_continuous_sessions_on_wednesday Float32,
    percentage_continuous_sessions_on_thursday Float32,
    percentage_continuous_sessions_on_friday Float32,
    percentage_continuous_sessions_on_saturday Float32,
    percentage_continuous_sessions_on_sunday Float32,
    median_continuous_output_call_duration Float32,
    quantile_90_continuous_output_call_duration Float32,
    quantile_10_continuous_output_call_duration Float32,
    percentage_continuous_output_long_output_calls Float32,
    percentage_continuous_output_short_output_calls Float32,
    percentage_continuous_output_average_output_calls Float32,
    percentage_continuous_output_sessions_between_00_04 Float32,
    percentage_continuous_output_sessions_between_04_08 Float32,
    percentage_continuous_output_sessions_between_08_12 Float32,
    percentage_continuous_output_sessions_between_12_16 Float32,
    percentage_continuous_output_sessions_between_16_20 Float32,
    percentage_continuous_output_sessions_between_20_24 Float32,
    percentage_continuous_output_sessions_on_weekday Float32,
    percentage_continuous_output_sessions_on_weekend Float32,
    percentage_continuous_output_sessions_on_monday Float32,
    percentage_continuous_output_sessions_on_tuesday Float32,
    percentage_continuous_output_sessions_on_wednesday Float32,
    percentage_continuous_output_sessions_on_thursday Float32,
    percentage_continuous_output_sessions_on_friday Float32,
    percentage_continuous_output_sessions_on_saturday Float32,
    percentage_continuous_output_sessions_on_sunday Float32,
    median_continuous_input_call_duration Float32,
    quantile_90_continuous_input_call_duration Float32,
    quantile_10_continuous_input_call_duration Float32,
    percentage_continuous_input_long_input_calls Float32,
    percentage_continuous_input_short_input_calls Float32,
    percentage_continuous_input_average_input_calls Float32,
    percentage_continuous_input_sessions_between_00_04 Float32,
    percentage_continuous_input_sessions_between_04_08 Float32,
    percentage_continuous_input_sessions_between_08_12 Float32,
    percentage_continuous_input_sessions_between_12_16 Float32,
    percentage_continuous_input_sessions_between_16_20 Float32,
    percentage_continuous_input_sessions_between_20_24 Float32,
    percentage_continuous_input_sessions_on_weekday Float32,
    percentage_continuous_input_sessions_on_weekend Float32,
    percentage_continuous_input_sessions_on_monday Float32,
    percentage_continuous_input_sessions_on_tuesday Float32,
    percentage_continuous_input_sessions_on_wednesday Float32,
    percentage_continuous_input_sessions_on_thursday Float32,
    percentage_continuous_input_sessions_on_friday Float32,
    percentage_continuous_input_sessions_on_saturday Float32,
    percentage_continuous_input_sessions_on_sunday Float32
) ENGINE = ReplacingMergeTree()
ORDER BY msisdn;

INSERT INTO {stats_db:Identifier}.{call_stats_table:Identifier}
WITH
    call_stat AS (
        SELECT
            msisdn_left AS msisdn,
            quantile(0.5)(dur) AS median_call_duration,
            quantile(0.9)(dur) AS quantile_90_call_duration,
            quantile(0.1)(dur) AS quantile_10_call_duration,
            countIf(dur > 60) * 100.0 / count() AS percentage_long_calls,
            countIf(dur < 15) * 100.0 / count() AS percentage_short_calls,
            countIf(15 < dur and dur < 60) * 100.0 / count() AS percentage_average_calls,
            countIf(toHour(dt) BETWEEN 0 AND 4) / count() * 100.0 AS percentage_sessions_between_00_04,
            countIf(toHour(dt) BETWEEN 4 AND 8) / count() * 100.0 AS percentage_sessions_between_04_08,
            countIf(toHour(dt) BETWEEN 8 AND 12) / count() * 100.0 AS percentage_sessions_between_08_12,
            countIf(toHour(dt) BETWEEN 12 AND 16) / count() * 100.0 AS percentage_sessions_between_12_16,
            countIf(toHour(dt) BETWEEN 16 AND 20) / count() * 100.0 AS percentage_sessions_between_16_20,
            countIf(toHour(dt) BETWEEN 20 AND 24) / count() * 100.0 AS percentage_sessions_between_20_24,
            countIf(toDayOfWeek(dt) BETWEEN 1 AND 5) / count() * 100.0 AS percentage_sessions_on_weekday,
            countIf(toDayOfWeek(dt) BETWEEN 6 AND 7) / count() * 100.0 AS percentage_sessions_on_weekend,
            countIf(toDayOfWeek(dt) = 1) * 100.0 / count() AS percentage_sessions_on_monday,
            countIf(toDayOfWeek(dt) = 2) * 100.0 / count() AS percentage_sessions_on_tuesday,
            countIf(toDayOfWeek(dt) = 3) * 100.0 / count() AS percentage_sessions_on_wednesday,
            countIf(toDayOfWeek(dt) = 4) * 100.0 / count() AS percentage_sessions_on_thursday,
            countIf(toDayOfWeek(dt) = 5) * 100.0 / count() AS percentage_sessions_on_friday,
            countIf(toDayOfWeek(dt) = 6) * 100.0 / count() AS percentage_sessions_on_saturday,
            countIf(toDayOfWeek(dt) = 7) * 100.0 / count() AS percentage_sessions_on_sunday
        FROM
            {sessions_db:Identifier}.{sessions_table:Identifier}
        GROUP BY
            msisdn_left
    ),
    output_call_stat AS (
        SELECT
            msisdn_left AS msisdn,
            quantile(0.5)(dur) AS median_output_call_duration,
            quantile(0.9)(dur) AS quantile_90_output_call_duration,
            quantile(0.1)(dur) AS quantile_10_output_call_duration,
            countIf(dur > 60) * 100.0 / count() AS percentage_long_output_calls,
            countIf(dur < 15) * 100.0 / count() AS percentage_short_output_calls,
            countIf(15 < dur and dur < 60) * 100.0 / count() AS percentage_average_output_calls,
            countIf(toHour(dt) BETWEEN 0 AND 4) / count() * 100.0 AS percentage_output_sessions_between_00_04,
            countIf(toHour(dt) BETWEEN 4 AND 8) / count() * 100.0 AS percentage_output_sessions_between_04_08,
            countIf(toHour(dt) BETWEEN 8 AND 12) / count() * 100.0 AS percentage_output_sessions_between_08_12,
            countIf(toHour(dt) BETWEEN 12 AND 16) / count() * 100.0 AS percentage_output_sessions_between_12_16,
            countIf(toHour(dt) BETWEEN 16 AND 20) / count() * 100.0 AS percentage_output_sessions_between_16_20,
            countIf(toHour(dt) BETWEEN 20 AND 24) / count() * 100.0 AS percentage_output_sessions_between_20_24,
            countIf(toDayOfWeek(dt) BETWEEN 1 AND 5) / count() * 100.0 AS percentage_output_sessions_on_weekday,
            countIf(toDayOfWeek(dt) BETWEEN 6 AND 7) / count() * 100.0 AS percentage_output_sessions_on_weekend,
            countIf(toDayOfWeek(dt) = 1) * 100.0 / count() AS percentage_output_sessions_on_monday,
            countIf(toDayOfWeek(dt) = 2) * 100.0 / count() AS percentage_output_sessions_on_tuesday,
            countIf(toDayOfWeek(dt) = 3) * 100.0 / count() AS percentage_output_sessions_on_wednesday,
            countIf(toDayOfWeek(dt) = 4) * 100.0 / count() AS percentage_output_sessions_on_thursday,
            countIf(toDayOfWeek(dt) = 5) * 100.0 / count() AS percentage_output_sessions_on_friday,
            countIf(toDayOfWeek(dt) = 6) * 100.0 / count() AS percentage_output_sessions_on_saturday,
            countIf(toDayOfWeek(dt) = 7) * 100.0 / count() AS percentage_output_sessions_on_sunday
        FROM
            {sessions_db:Identifier}.{sessions_table:Identifier}
        WHERE
            is_outgoing == true
        GROUP BY
            msisdn_left
    ),
    input_call_stat AS (
        SELECT
            msisdn_left AS msisdn,
            quantile(0.5)(dur) AS median_input_call_duration,
            quantile(0.9)(dur) AS quantile_90_input_call_duration,
            quantile(0.1)(dur) AS quantile_10_input_call_duration,
            countIf(dur > 60) * 100.0 / count() AS percentage_long_input_calls,
            countIf(dur < 15) * 100.0 / count() AS percentage_short_input_calls,
            countIf(15 < dur and dur < 60) * 100.0 / count() AS percentage_average_input_calls,
            countIf(toHour(dt) BETWEEN 0 AND 4) / count() * 100.0 AS percentage_input_sessions_between_00_04,
            countIf(toHour(dt) BETWEEN 4 AND 8) / count() * 100.0 AS percentage_input_sessions_between_04_08,
            countIf(toHour(dt) BETWEEN 8 AND 12) / count() * 100.0 AS percentage_input_sessions_between_08_12,
            countIf(toHour(dt) BETWEEN 12 AND 16) / count() * 100.0 AS percentage_input_sessions_between_12_16,
            countIf(toHour(dt) BETWEEN 16 AND 20) / count() * 100.0 AS percentage_input_sessions_between_16_20,
            countIf(toHour(dt) BETWEEN 20 AND 24) / count() * 100.0 AS percentage_input_sessions_between_20_24,
            countIf(toDayOfWeek(dt) BETWEEN 1 AND 5) / count() * 100.0 AS percentage_input_sessions_on_weekday,
            countIf(toDayOfWeek(dt) BETWEEN 6 AND 7) / count() * 100.0 AS percentage_input_sessions_on_weekend,
            countIf(toDayOfWeek(dt) = 1) * 100.0 / count() AS percentage_input_sessions_on_monday,
            countIf(toDayOfWeek(dt) = 2) * 100.0 / count() AS percentage_input_sessions_on_tuesday,
            countIf(toDayOfWeek(dt) = 3) * 100.0 / count() AS percentage_input_sessions_on_wednesday,
            countIf(toDayOfWeek(dt) = 4) * 100.0 / count() AS percentage_input_sessions_on_thursday,
            countIf(toDayOfWeek(dt) = 5) * 100.0 / count() AS percentage_input_sessions_on_friday,
            countIf(toDayOfWeek(dt) = 6) * 100.0 / count() AS percentage_input_sessions_on_saturday,
            countIf(toDayOfWeek(dt) = 7) * 100.0 / count() AS percentage_input_sessions_on_sunday
        FROM
            {sessions_db:Identifier}.{sessions_table:Identifier}
        WHERE
            is_outgoing == false
        GROUP BY
            msisdn_left
    ),
    continuous_call_stat AS (
        SELECT
            msisdn_left AS msisdn,
            quantile(0.5)(dur) AS median_continuous_call_duration,
            quantile(0.9)(dur) AS quantile_90_continuous_call_duration,
            quantile(0.1)(dur) AS quantile_10_continuous_call_duration,
            countIf(dur > 60) * 100.0 / count() AS percentage_long_continuous_calls,
            countIf(dur < 15) * 100.0 / count() AS percentage_short_continuous_calls,
            countIf(15 < dur and dur < 60) * 100.0 / count() AS percentage_average_continuous_calls,
            countIf(toHour(dt) BETWEEN 0 AND 4) / count() * 100.0 AS percentage_continuous_sessions_between_00_04,
            countIf(toHour(dt) BETWEEN 4 AND 8) / count() * 100.0 AS percentage_continuous_sessions_between_04_08,
            countIf(toHour(dt) BETWEEN 8 AND 12) / count() * 100.0 AS percentage_continuous_sessions_between_08_12,
            countIf(toHour(dt) BETWEEN 12 AND 16) / count() * 100.0 AS percentage_continuous_sessions_between_12_16,
            countIf(toHour(dt) BETWEEN 16 AND 20) / count() * 100.0 AS percentage_continuous_sessions_between_16_20,
            countIf(toHour(dt) BETWEEN 20 AND 24) / count() * 100.0 AS percentage_continuous_sessions_between_20_24,
            countIf(toDayOfWeek(dt) BETWEEN 1 AND 5) / count() * 100.0 AS percentage_continuous_sessions_on_weekday,
            countIf(toDayOfWeek(dt) BETWEEN 6 AND 7) / count() * 100.0 AS percentage_continuous_sessions_on_weekend,
            countIf(toDayOfWeek(dt) = 1) * 100.0 / count() AS percentage_continuous_sessions_on_monday,
            countIf(toDayOfWeek(dt) = 2) * 100.0 / count() AS percentage_continuous_sessions_on_tuesday,
            countIf(toDayOfWeek(dt) = 3) * 100.0 / count() AS percentage_continuous_sessions_on_wednesday,
            countIf(toDayOfWeek(dt) = 4) * 100.0 / count() AS percentage_continuous_sessions_on_thursday,
            countIf(toDayOfWeek(dt) = 5) * 100.0 / count() AS percentage_continuous_sessions_on_friday,
            countIf(toDayOfWeek(dt) = 6) * 100.0 / count() AS percentage_continuous_sessions_on_saturday,
            countIf(toDayOfWeek(dt) = 7) * 100.0 / count() AS percentage_continuous_sessions_on_sunday
        FROM
            {sessions_db:Identifier}.{sessions_table:Identifier}
        WHERE
            dur > 0
        GROUP BY
            msisdn_left
    ),
    continuous_output_call_stat AS (
        SELECT
            msisdn_left AS msisdn,
            quantile(0.5)(dur) AS median_continuous_output_call_duration,
            quantile(0.9)(dur) AS quantile_90_continuous_output_call_duration,
            quantile(0.1)(dur) AS quantile_10_continuous_output_call_duration,
            countIf(dur > 60) * 100.0 / count() AS percentage_continuous_output_long_output_calls,
            countIf(dur < 15) * 100.0 / count() AS percentage_continuous_output_short_output_calls,
            countIf(15 < dur and dur < 60) * 100.0 / count() AS percentage_continuous_output_average_output_calls,
            countIf(toHour(dt) BETWEEN 0 AND 4) / count() * 100.0 AS percentage_continuous_output_sessions_between_00_04,
            countIf(toHour(dt) BETWEEN 4 AND 8) / count() * 100.0 AS percentage_continuous_output_sessions_between_04_08,
            countIf(toHour(dt) BETWEEN 8 AND 12) / count() * 100.0 AS percentage_continuous_output_sessions_between_08_12,
            countIf(toHour(dt) BETWEEN 12 AND 16) / count() * 100.0 AS percentage_continuous_output_sessions_between_12_16,
            countIf(toHour(dt) BETWEEN 16 AND 20) / count() * 100.0 AS percentage_continuous_output_sessions_between_16_20,
            countIf(toHour(dt) BETWEEN 20 AND 24) / count() * 100.0 AS percentage_continuous_output_sessions_between_20_24,
            countIf(toDayOfWeek(dt) BETWEEN 1 AND 5) / count() * 100.0 AS percentage_continuous_output_sessions_on_weekday,
            countIf(toDayOfWeek(dt) BETWEEN 6 AND 7) / count() * 100.0 AS percentage_continuous_output_sessions_on_weekend,
            countIf(toDayOfWeek(dt) = 1) * 100.0 / count() AS percentage_continuous_output_sessions_on_monday,
            countIf(toDayOfWeek(dt) = 2) * 100.0 / count() AS percentage_continuous_output_sessions_on_tuesday,
            countIf(toDayOfWeek(dt) = 3) * 100.0 / count() AS percentage_continuous_output_sessions_on_wednesday,
            countIf(toDayOfWeek(dt) = 4) * 100.0 / count() AS percentage_continuous_output_sessions_on_thursday,
            countIf(toDayOfWeek(dt) = 5) * 100.0 / count() AS percentage_continuous_output_sessions_on_friday,
            countIf(toDayOfWeek(dt) = 6) * 100.0 / count() AS percentage_continuous_output_sessions_on_saturday,
            countIf(toDayOfWeek(dt) = 7) * 100.0 / count() AS percentage_continuous_output_sessions_on_sunday
        FROM
            {sessions_db:Identifier}.{sessions_table:Identifier}
        WHERE
            dur > 0 and is_outgoing == true
        GROUP BY
            msisdn_left
    ),
    continuous_input_call_stat AS (
        SELECT
            msisdn_left AS msisdn,
            quantile(0.5)(dur) AS median_continuous_input_call_duration,
            quantile(0.9)(dur) AS quantile_90_continuous_input_call_duration,
            quantile(0.1)(dur) AS quantile_10_continuous_input_call_duration,
            countIf(dur > 60) * 100.0 / count() AS percentage_continuous_input_long_input_calls,
            countIf(dur < 15) * 100.0 / count() AS percentage_continuous_input_short_input_calls,
            countIf(15 < dur and dur < 60) * 100.0 / count() AS percentage_continuous_input_average_input_calls,
            countIf(toHour(dt) BETWEEN 0 AND 4) / count() * 100.0 AS percentage_continuous_input_sessions_between_00_04,
            countIf(toHour(dt) BETWEEN 4 AND 8) / count() * 100.0 AS percentage_continuous_input_sessions_between_04_08,
            countIf(toHour(dt) BETWEEN 8 AND 12) / count() * 100.0 AS percentage_continuous_input_sessions_between_08_12,
            countIf(toHour(dt) BETWEEN 12 AND 16) / count() * 100.0 AS percentage_continuous_input_sessions_between_12_16,
            countIf(toHour(dt) BETWEEN 16 AND 20) / count() * 100.0 AS percentage_continuous_input_sessions_between_16_20,
            countIf(toHour(dt) BETWEEN 20 AND 24) / count() * 100.0 AS percentage_continuous_input_sessions_between_20_24,
            countIf(toDayOfWeek(dt) BETWEEN 1 AND 5) / count() * 100.0 AS percentage_continuous_input_sessions_on_weekday,
            countIf(toDayOfWeek(dt) BETWEEN 6 AND 7) / count() * 100.0 AS percentage_continuous_input_sessions_on_weekend,
            countIf(toDayOfWeek(dt) = 1) * 100.0 / count() AS percentage_continuous_input_sessions_on_monday,
            countIf(toDayOfWeek(dt) = 2) * 100.0 / count() AS percentage_continuous_input_sessions_on_tuesday,
            countIf(toDayOfWeek(dt) = 3) * 100.0 / count() AS percentage_continuous_input_sessions_on_wednesday,
            countIf(toDayOfWeek(dt) = 4) * 100.0 / count() AS percentage_continuous_input_sessions_on_thursday,
            countIf(toDayOfWeek(dt) = 5) * 100.0 / count() AS percentage_continuous_input_sessions_on_friday,
            countIf(toDayOfWeek(dt) = 6) * 100.0 / count() AS percentage_continuous_input_sessions_on_saturday,
            countIf(toDayOfWeek(dt) = 7) * 100.0 / count() AS percentage_continuous_input_sessions_on_sunday
        FROM
            {sessions_db:Identifier}.{sessions_table:Identifier}
        WHERE
            dur > 0 and is_outgoing == false
        GROUP BY
            msisdn_left
    )
SELECT call_stat.msisdn as msisdn, COLUMNS('[^(msisdn)]')
FROM
    call_stat
LEFT OUTER JOIN
    output_call_stat ON call_stat.msisdn = output_call_stat.msisdn
LEFT OUTER JOIN
    input_call_stat ON call_stat.msisdn = input_call_stat.msisdn
LEFT OUTER JOIN
    continuous_call_stat ON call_stat.msisdn = continuous_call_stat.msisdn
LEFT OUTER JOIN
    continuous_output_call_stat ON call_stat.msisdn = continuous_output_call_stat.msisdn
LEFT OUTER JOIN
    continuous_input_call_stat ON call_stat.msisdn = continuous_input_call_stat.msisdn;