CREATE DATABASE IF NOT EXISTS {sessions_db:Identifier} ON CLUSTER 'bic_cluster';

CREATE TABLE IF NOT EXISTS {sessions_db:Identifier}.{sessions_table:Identifier} ON CLUSTER 'bic_cluster' (
    dt DateTime,
    dur UInt32,
    msisdn_left String,
    msisdn_right String,
    mcc_left String,
    mcc_right String,
    cellid_left String,
    cellid_right String,
    is_outgoing Bool
) ENGINE = MergeTree()
ORDER BY msisdn_left;
