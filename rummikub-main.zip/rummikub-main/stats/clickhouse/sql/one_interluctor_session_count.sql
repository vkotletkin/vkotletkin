CREATE DATABASE IF NOT EXISTS {stats_db:Identifier} ON CLUSTER 'bic_cluster';

CREATE TABLE IF NOT EXISTS {stats_db:Identifier}.{one_interluctor_count_table:Identifier} ON CLUSTER 'bic_cluster' (
    msisdn String,
    quantile_10_sessions_with_one_interlocutor Float32,
    median_sessions_with_one_interlocutor Float32,
    quantile_90_sessions_with_one_interlocutor Float32,
    quantile_10_output_sessions_with_one_interlocutor Float32,
    median_output_sessions_with_one_interlocutor Float32,
    quantile_90_output_sessions_with_one_interlocutor Float32,
    quantile_10_input_sessions_with_one_interlocutor Float32,
    median_input_sessions_with_one_interlocutor Float32,
    quantile_90_input_sessions_with_one_interlocutor Float32,
    quantile_10_continuous_sessions_with_one_interlocutor Float32,
    median_continuous_sessions_with_one_interlocutor Float32,
    quantile_90_continuous_sessions_with_one_interlocutor Float32,
    quantile_10_continuous_output_sessions_with_one_interlocutor Float32,
    median_continuous_output_sessions_with_one_interlocutor Float32,
    quantile_90_continuous_output_sessions_with_one_interlocutor Float32,
    quantile_10_continuous_input_sessions_with_one_interlocutor Float32,
    median_continuous_input_sessions_with_one_interlocutor Float32,
    quantile_90_continuous_input_sessions_with_one_interlocutor Float32
) ENGINE = ReplacingMergeTree()
ORDER BY msisdn;

INSERT INTO {stats_db:Identifier}.{one_interluctor_count_table:Identifier}
WITH
    one_interlocutor_count AS (
        WITH session_counts AS (
            SELECT
                msisdn_left AS msisdn,
                msisdn_right,
                count() AS session_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            GROUP BY
                msisdn_left, msisdn_right
        )
        SELECT
            msisdn,
            quantile(0.1)(session_count) AS quantile_10_sessions_with_one_interlocutor,
            quantile(0.5)(session_count) AS median_sessions_with_one_interlocutor,
            quantile(0.9)(session_count) AS quantile_90_sessions_with_one_interlocutor
        FROM
            session_counts
        GROUP BY
            msisdn
    ),
    one_interlocutor_output_count AS (
        WITH output_session_counts AS (
            SELECT
                msisdn_left AS msisdn,
                msisdn_right,
                count() AS session_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            WHERE
                is_outgoing == true
            GROUP BY
                msisdn_left, msisdn_right
        )
        SELECT
            msisdn,
            quantile(0.1)(session_count) AS quantile_10_output_sessions_with_one_interlocutor,
            quantile(0.5)(session_count) AS median_output_sessions_with_one_interlocutor,
            quantile(0.9)(session_count) AS quantile_90_output_sessions_with_one_interlocutor
        FROM
            output_session_counts
        GROUP BY
            msisdn
    ),
    one_interlocutor_input_count AS (
        WITH input_session_counts AS (
            SELECT
                msisdn_left AS msisdn,
                msisdn_right,
                count() AS session_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            WHERE
                is_outgoing == false
            GROUP BY
                msisdn_left, msisdn_right
        )
        SELECT
            msisdn,
            quantile(0.1)(session_count) AS quantile_10_input_sessions_with_one_interlocutor,
            quantile(0.5)(session_count) AS median_input_sessions_with_one_interlocutor,
            quantile(0.9)(session_count) AS quantile_90_input_sessions_with_one_interlocutor
        FROM
            input_session_counts
        GROUP BY
            msisdn
    ),
    one_interlocutor_continuous_count AS (
        WITH continuous_session_counts AS (
            SELECT
                msisdn_left AS msisdn,
                msisdn_right,
                count() AS session_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            WHERE
                dur > 0
            GROUP BY
                msisdn_left, msisdn_right
        )
        SELECT
            msisdn,
            quantile(0.1)(session_count) AS quantile_10_continuous_sessions_with_one_interlocutor,
            quantile(0.5)(session_count) AS median_continuous_sessions_with_one_interlocutor,
            quantile(0.9)(session_count) AS quantile_90_continuous_sessions_with_one_interlocutor
        FROM
            continuous_session_counts
        GROUP BY
            msisdn
    ),
    one_interlocutor_continuous_output_count AS (
        WITH continuous_output_session_counts AS (
            SELECT
                msisdn_left AS msisdn,
                msisdn_right,
                count() AS session_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            WHERE
                dur > 0 and is_outgoing == true
            GROUP BY
                msisdn_left, msisdn_right
        )
        SELECT
            msisdn,
            quantile(0.1)(session_count) AS quantile_10_continuous_output_sessions_with_one_interlocutor,
            quantile(0.5)(session_count) AS median_continuous_output_sessions_with_one_interlocutor,
            quantile(0.9)(session_count) AS quantile_90_continuous_output_sessions_with_one_interlocutor
        FROM
            continuous_output_session_counts
        GROUP BY
            msisdn
    ),
    one_interlocutor_continuous_input_count AS (
        WITH continuous_input_session_counts AS (
            SELECT
                msisdn_left AS msisdn,
                msisdn_right,
                count() AS session_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            WHERE
                dur > 0 and is_outgoing == false
            GROUP BY
                msisdn_left, msisdn_right
        )
        SELECT
            msisdn,
            quantile(0.1)(session_count) AS quantile_10_continuous_input_sessions_with_one_interlocutor,
            quantile(0.5)(session_count) AS median_continuous_input_sessions_with_one_interlocutor,
            quantile(0.9)(session_count) AS quantile_90_continuous_input_sessions_with_one_interlocutor
        FROM
            continuous_input_session_counts
        GROUP BY
            msisdn
    )
SELECT one_interlocutor_count.msisdn as msisdn, COLUMNS('[^(msisdn)]')
FROM
    one_interlocutor_count AS t1
LEFT OUTER JOIN
    one_interlocutor_output_count AS t2 ON t1.msisdn = t2.msisdn
LEFT OUTER JOIN
    one_interlocutor_input_count AS t3 ON t1.msisdn = t3.msisdn
LEFT OUTER JOIN
    one_interlocutor_continuous_count AS t4 ON t1.msisdn = t4.msisdn
LEFT OUTER JOIN
    one_interlocutor_continuous_output_count AS t5 ON t1.msisdn = t5.msisdn
LEFT OUTER JOIN
    one_interlocutor_continuous_output_count AS t6 ON t1.msisdn = t6.msisdn;
