CREATE DATABASE IF NOT EXISTS {stats_db:Identifier} ON CLUSTER 'bic_cluster';

CREATE TABLE IF NOT EXISTS {stats_db:Identifier}.{base_stations_by_day_table:Identifier} ON CLUSTER 'bic_cluster' (
    msisdn String,
    quantile_10_unique_base_stations_per_day Float32,
    median_unique_base_stations_per_day Float32,
    quantile_90_unique_base_stations_per_day Float32,
    quantile_10_unique_output_base_stations_per_day Float32,
    median_unique_output_base_stations_per_day Float32,
    quantile_90_unique_output_base_stations_per_day Float32,
    quantile_10_unique_input_base_stations_per_day Float32,
    median_unique_input_base_stations_per_day Float32,
    quantile_90_unique_input_base_stations_per_day Float32
) ENGINE = ReplacingMergeTree()
ORDER BY msisdn;

INSERT INTO {stats_db:Identifier}.{base_stations_by_day_table:Identifier}
WITH
    unique_base_station_count AS (
        WITH daily_unique_base_stations AS (
            SELECT
                msisdn_left AS msisdn,
                toDate(dt) AS day,
                uniq(cellid_left) AS unique_base_station_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            GROUP BY
                msisdn_left,
                day
        )
        SELECT
            msisdn,
            quantile(0.1)(unique_base_station_count) AS quantile_10_unique_base_stations_per_day,
            quantile(0.5)(unique_base_station_count) AS median_unique_base_stations_per_day,
            quantile(0.9)(unique_base_station_count) AS quantile_90_unique_base_stations_per_day
        FROM
            daily_unique_base_stations
        GROUP BY
            msisdn
    ),
    unique_output_base_station_count AS (
        WITH daily_unique_output_base_stations AS (
            SELECT
                msisdn_left AS msisdn,
                toDate(dt) AS day,
                uniq(cellid_left) AS unique_base_station_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            WHERE
                is_outgoing == true
            GROUP BY
                msisdn_left,
                day
        )
        SELECT
            msisdn,
            quantile(0.1)(unique_base_station_count) AS quantile_10_unique_output_base_stations_per_day,
            quantile(0.5)(unique_base_station_count) AS median_unique_output_base_stations_per_day,
            quantile(0.9)(unique_base_station_count) AS quantile_90_unique_output_base_stations_per_day
        FROM
            daily_unique_output_base_stations
        GROUP BY
            msisdn
    ),
    unique_input_base_station_count AS (
        WITH daily_unique_input_base_stations AS (
            SELECT
                msisdn_left AS msisdn,
                toDate(dt) AS day,
                uniq(cellid_right) AS unique_base_station_count
            FROM
                {sessions_db:Identifier}.{sessions_table:Identifier}
            WHERE
                is_outgoing == false
            GROUP BY
                msisdn_left,
                day
        )
        SELECT
            msisdn,
            quantile(0.1)(unique_base_station_count) AS quantile_10_unique_input_base_stations_per_day,
            quantile(0.5)(unique_base_station_count) AS median_unique_input_base_stations_per_day,
            quantile(0.9)(unique_base_station_count) AS quantile_90_unique_input_base_stations_per_day
        FROM
            daily_unique_input_base_stations
        GROUP BY
            msisdn
    )
SELECT unique_base_station_count.msisdn as msisdn, COLUMNS('[^(msisdn)]')
FROM
    unique_base_station_count AS t1
LEFT OUTER JOIN
    unique_output_base_station_count AS t2 ON t1.msisdn = t2.msisdn
LEFT OUTER JOIN
    unique_input_base_station_count AS t3 ON t1.msisdn = t3.msisdn;