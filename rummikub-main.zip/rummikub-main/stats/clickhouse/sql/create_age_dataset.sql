INSERT INTO FUNCTION s3({s3_dataset_resource:String}, {access_key_id:String}, {secret_access_key:String}, {dataset_file_format:String})
WITH
	targets AS (
		SELECT * FROM s3({s3_target_resource:String}, {access_key_id:String}, {secret_access_key:String}, {target_file_format:String})
	),
	features AS (
		SELECT * FROM {stats_db:Identifier}.{all_stats_mv_table_name:Identifier} FINAL
	)
SELECT
	toYear(now()) - toInt16(targets.{target_col:Identifier}) as AGE,
	features.*
FROM
	 targets
INNER JOIN
	features ON targets.{target_msisdn:Identifier} = features.msisdn;