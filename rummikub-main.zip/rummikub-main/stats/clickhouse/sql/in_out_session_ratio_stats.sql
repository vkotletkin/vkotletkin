CREATE DATABASE IF NOT EXISTS {stats_db:Identifier} ON CLUSTER 'bic_cluster';

CREATE TABLE IF NOT EXISTS {stats_db:Identifier}.{in_out_ratio_stats_table:Identifier} ON CLUSTER 'bic_cluster' (
    msisdn String,
    outgoing_sessions_count Float32,
    incoming_sessions_count Float32,
    outgoing_to_incoming_ratio Float32,
    outgoing_continuous_sessions_count Float32,
    incoming_continuous_sessions_count Float32,
    outgoing_to_incoming_continuous_ratio Float32
) ENGINE = ReplacingMergeTree()
ORDER BY msisdn;

INSERT INTO {stats_db:Identifier}.{in_out_ratio_stats_table:Identifier}
WITH incoming_outgoing_sessions_ratio AS (
        SELECT
            msisdn_left AS msisdn,
            countIf(is_outgoing = true) AS outgoing_sessions_count,
            countIf(is_outgoing = false) AS incoming_sessions_count,
            intDivOrZero(outgoing_sessions_count, incoming_sessions_count) AS outgoing_to_incoming_ratio
        FROM
            {sessions_db:Identifier}.{sessions_table:Identifier}
        GROUP BY
            msisdn
    ),
    continuous_incoming_outgoing_sessions_ratio AS (
        SELECT
            msisdn_left AS msisdn,
            countIf(is_outgoing = true) AS outgoing_continuous_sessions_count,
            countIf(is_outgoing = false) AS incoming_continuous_sessions_count,
            intDivOrZero(outgoing_continuous_sessions_count, incoming_continuous_sessions_count) AS outgoing_to_incoming_continuous_ratio
        FROM
            {sessions_db:Identifier}.{sessions_table:Identifier}
        WHERE
            dur > 0
        GROUP BY
            msisdn
    )
SELECT incoming_outgoing_sessions_ratio.msisdn as msisdn, COLUMNS('[^(msisdn)]')
FROM
    incoming_outgoing_sessions_ratio
LEFT OUTER JOIN
    continuous_incoming_outgoing_sessions_ratio ON incoming_outgoing_sessions_ratio.msisdn = continuous_incoming_outgoing_sessions_ratio.msisdn;