## Preparation

### Settings

Обучение модели может быть долгим и не укладываться в таймаут вашего репозитория. Заранее установите таймаут на несколько часов в Project → Settings → CI/CD → General Pipelines → Timeout.

### Variables

В настройках раннера вы должны определить следующие переменные:

- DOCKER_REGISTRY - docker registry с которым мы будем работать в пайплайне. Пример: DOCKER_REGISTRY="nexus.baltinfocom.ru/docker-private".

В настройках репозитория вы должны определить следующие переменные:

- DOCKER_REGISTRY_USER - пользователь docker registry с правами на pull и push. Пример: DOCKER_REGISTRY_USER="gitlabci"
- DOCKER_REGISTRY_PASS - пароль для пользователя docker registry.
- MLFLOW_TRACKING_URI - tracking uri для mlflow. Пример: "http://mlflow.tracking.server.com:5000".
- MLFLOW_S3_ENDPOINT_URL - эндпоинт minio в котором хранятся атефакты mlflow. Пример: "http://minio.adr.com:9200".
- AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY - key id/secret key для minio в котором хранятся атефакты mlflow.
- PIP_CONF - файл `pip.conf1`. Должен содержать поля `index`, `index-url` и `trusted-host`. Пример: 
```conf
[global]
index = http://192.168.1.40:8081/repository/bento-py/simple
index-url = http://192.168.1.40:8081/repository/bento-py/simple
trusted-host = 192.168.1.40
```

### Docker Images

В вашем docker registry должны быть доступны образы, используемые в gitlab ci pipeline. 

`ubuntu-dind:latest` - образ используется, как базовый dind-образ для сборки bentoml-сервиса и исполнения mlproject.
`python:3.10-slim` - образ используется, как базовый для bentoml-сервиса и mlproject docker-контйнера.

## Train

Мы предлагаем два способа запуска обучения моделей. Запланированный и ручной. 


### Planned

В `.gitlab-ci.yml` написан шаблон для запуска задачи обучения в автоматическом режиме. Задача запускается, когда вносятся изменения в файлы mlproject (с наличием dvc можно запускать задачу при обновлении датасета). Для создания такой запланированной задачи достаточно добавить задачу в `.gitlab-ci.yml`, отнаследоваться от задачи `.base-train`, задать стандартный файл конфигурации в `stats/planned_experiments` и указать путь к этому файлу в `variables: DEFAULT_TRAIN_CONFIG`.   
  
В стандартном `.gitlab-ci.yml` созданы задачи запланированного обучения `train-gender-prediction`, `train-age-group-prediction-v1`, `train-age-group-prediction-v2` (предсказания возрастной группы отличаются количеством возрастных групп). Настройки можно задать через переменные (gitlab ci file variable) `GENDER_PREDICTION_CONFIG`, `AGE_GROUP_PREDICTION_CONFIG_V1` и `AGE_GROUP_PREDICTION_CONFIG_V2`. Настройки по умолчанию задаются в директории `stats/planned_experiments`.  
  
Запланированное обучение можно отключить через переменные окружения. Установите `ALL_PLANED_IS_DISABLED=true`, чтобы отключить все запланированные задачи обучения или `GENDER_PREDICTION_TRAIN_IS_DISABLED` чтобы отключить только обучение модели определения пола. Для отключения обучения моделей определения возрастной группы установите флаги `AGE_GROUP_PREDICTION_V1_IS_DISABLED` или `AGE_GROUP_PREDICTION_V2_IS_DISABLED` соответственно.  
  
Конфигурацию запуска запланированных задач можно изменить, задав переменные-файлы с названием `GENDER_PREDICTION_CONFIG`, `AGE_GROUP_PREDICTION_CONFIG_V1` и `AGE_GROUP_PREDICTION_CONFIG_V2`. Эти настройки будут использоваться для запуска соответствующих экспериментов.  
  
### Manual train

Чтобы запустить задачу на кастомное обучение модели запустите пайплайн (кнопка "Run pipeline"), в `variables` задайте флаг `CUSTOM_TRAIN_ONLY = true`, имя эксперимента в переменной `MLFLOW_EXPERIMENT_NAME` и в `TRAIN_CONFIG` переменной (gitlab ci file variable) задайте конфигурацию обучения. 

### GPU

Если вы выполняете обучение модели с использованием GPU, вы должны использовать образ MLproject совместимый с CUDA установленной на машине. Образ можно задать через переменную `MLPROJECT_IMAGE_TAG`.  

В конфигурации эксперимента нужно задать параметры для использования видеокарты. В конфигурацию эксперимента добавьте следующий текст:

```json
...
	"default_params": {
		"task_type": "GPU",
		...
	}
...
```

Чтобы указать, какие карты должны использоваться при обучении задайте переменную `GPUS` при запуске пайплайна. Например, `GPUS=all` будет означать, что при обучении могут использоваться все видеокарты, а `GPUS=""`, что gpu не может использоваться из контейнера.  