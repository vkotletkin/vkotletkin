from enum import Enum
from typing import Set, Generator
from functools import lru_cache
from itertools import chain

from pyspark.sql import functions as f


# I understand that this is very bad, but there simply was not enough time to create a more complex generation process.


class InputSchema(Enum):
    NUMBER_TUPLE_ID = 'number_tuple_id'
    INTERLOCUTOR_NUMBER_TUPLE_ID = 'interlocutor_number_tuple_id'
    S_DT = 's_dt'
    S_DUR = 's_dur'
    IS_OUTGOING = 'is_outgoing'


class FeatureType(Enum):
    ALL = 'all'
    BASIC = 'basic'
    YEAR = 'year'
    MONTH = 'month'
    DAY = 'day'
    WEEK = 'week'


STANDARD_CONDITIONS = {
    '': 'true',
    'not_null_': f.col(InputSchema.S_DUR.value) > 0,
    'out_': f.col(InputSchema.IS_OUTGOING.value) == True,
    'in_': f.col(InputSchema.IS_OUTGOING.value) == False,
    'not_null_out_': (f.col(InputSchema.IS_OUTGOING.value) == True) & (f.col(InputSchema.S_DUR.value) > 0),
    'not_null_in_': (f.col(InputSchema.IS_OUTGOING.value) == False) & (f.col(InputSchema.S_DUR.value) > 0)
}

BASIC_AGGREGATION_PATTERNS = {
    'median_{cond}s_duration': (lambda alias: f.percentile(f.col(InputSchema.S_DUR.value), 0.5).alias(alias)),
    'max_{cond}s_duration': (lambda alias: f.max(f.col(InputSchema.S_DUR.value)).alias(alias)),
    'perc_85_{cond}s_duration': (lambda alias: f.percentile(f.col(InputSchema.S_DUR.value), 0.85).alias(alias)),
    'percent_{cond}g_60_s_sessions': (lambda alias: (f.count_if(f.col(InputSchema.S_DUR.value) > 60) / f.count(InputSchema.S_DUR.value)).alias(alias)),
    'percent_{cond}g_30_s_sessions': (lambda alias: (f.count_if(f.col(InputSchema.S_DUR.value) > 30) / f.count(InputSchema.S_DUR.value)).alias(alias)),
    'percent_{cond}g_15_s_sessions': (lambda alias: (f.count_if(f.col(InputSchema.S_DUR.value) > 15) / f.count(InputSchema.S_DUR.value)).alias(alias)),
    'percent_{cond}l_15_s_sessions': (lambda alias: (f.count_if(f.col(InputSchema.S_DUR.value) < 10) / f.count(InputSchema.S_DUR.value)).alias(alias)),
}

PERIOD_AGGREGATION_PATTERNS = {
    'median_{cond}interlocutor_by_{period}': (lambda period, alias: f.percentile(f.col(period), 0.5).alias(alias)),
    'max_{cond}interlocutor_by_{period}': (lambda period, alias: f.max(f.col(period)).alias(alias)),
    'perc_85_{cond}interlocutor_by_{period}': (lambda period, alias: f.percentile(f.col(period), 0.85).alias(alias)),
}

WEEK_AGGREGATION_PATTERNS = {
    '{cond}sunday_part_sessions': (lambda alias: (f.count_if(f.col('dayofweek') == 1) / f.count('dayofweek')).alias(alias)),
    '{cond}monday_part_sessions': (lambda alias: (f.count_if(f.col('dayofweek') == 2) / f.count('dayofweek')).alias(alias)),
    '{cond}tuesday_part_sessions': (lambda alias: (f.count_if(f.col('dayofweek') == 3) / f.count('dayofweek')).alias(alias)),
    '{cond}wednesday_part_sessions': (lambda alias: (f.count_if(f.col('dayofweek') == 4) / f.count('dayofweek')).alias(alias)),
    '{cond}thursday_part_sessions': (lambda alias: (f.count_if(f.col('dayofweek') == 5) / f.count('dayofweek')).alias(alias)),
    '{cond}friday_part_sessions': (lambda alias: (f.count_if(f.col('dayofweek') == 6) / f.count('dayofweek')).alias(alias)),
    '{cond}saturday_part_sessions': (lambda alias: (f.count_if(f.col('dayofweek') == 7) / f.count('dayofweek')).alias(alias)),
}


def mix_agg_cond(conditions_patterns, aggregation_patterns, **kwargs):
    aggregations, conditions = {}, {}
    for cond_name, cond in conditions_patterns.items():
        for alias_pattern, aggregation_factory in aggregation_patterns.items():
            alias = alias_pattern.format(cond=cond_name, **kwargs)
            aggregations[alias] = aggregation_factory(alias=alias, **kwargs)
            conditions[alias] = cond

    return aggregations, conditions


BASIC_AGGREGATIONS, BASIC_CONDITIONS = mix_agg_cond(STANDARD_CONDITIONS, BASIC_AGGREGATION_PATTERNS)
YEAR_AGGREGATIONS, YEAR_CONDITIONS = mix_agg_cond(STANDARD_CONDITIONS, PERIOD_AGGREGATION_PATTERNS, period=FeatureType.YEAR.value)
MONTH_AGGREGATIONS, MONTH_CONDITIONS = mix_agg_cond(STANDARD_CONDITIONS, PERIOD_AGGREGATION_PATTERNS, period=FeatureType.MONTH.value)
DAY_AGGREGATIONS, DAY_CONDITIONS = mix_agg_cond(STANDARD_CONDITIONS, PERIOD_AGGREGATION_PATTERNS, period=FeatureType.DAY.value)
WEEK_AGGREGATIONS, WEEK_CONDITIONS = mix_agg_cond(STANDARD_CONDITIONS, WEEK_AGGREGATION_PATTERNS)

TYPE_TO_AGGREGATION = {
    FeatureType.BASIC: BASIC_AGGREGATIONS,
    FeatureType.YEAR: YEAR_AGGREGATIONS,
    FeatureType.MONTH: MONTH_AGGREGATIONS,
    FeatureType.DAY: DAY_AGGREGATIONS,
    FeatureType.YEAR.WEEK: WEEK_AGGREGATIONS,
}
TYPE_TO_CONDITION = {
    FeatureType.BASIC: BASIC_CONDITIONS,
    FeatureType.YEAR: YEAR_CONDITIONS,
    FeatureType.MONTH: MONTH_CONDITIONS,
    FeatureType.DAY: DAY_CONDITIONS,
    FeatureType.YEAR.WEEK: WEEK_CONDITIONS,
}
TYPE_TO_FEATURES = {feat_type: set(aggregations.keys()) for feat_type, aggregations in TYPE_TO_AGGREGATION.items()}
TYPE_TO_FEATURES[FeatureType.ALL] = set(chain.from_iterable(TYPE_TO_FEATURES.values()))
