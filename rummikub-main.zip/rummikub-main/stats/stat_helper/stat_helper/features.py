from enum import Enum
from typing import Set, Generator, Tuple
from functools import lru_cache

from pyspark.sql import functions as f

# I understand that this is not ideal, but there simply was not enough time to create a more complex generation process.
from .const import (
    BASIC_AGGREGATIONS,
    BASIC_CONDITIONS,
    YEAR_AGGREGATIONS,
    YEAR_CONDITIONS,
    MONTH_AGGREGATIONS,
    MONTH_CONDITIONS,
    DAY_AGGREGATIONS,
    DAY_CONDITIONS,
    WEEK_AGGREGATIONS,
    WEEK_CONDITIONS,
    TYPE_TO_AGGREGATION,
    TYPE_TO_CONDITION,
    TYPE_TO_FEATURES,
    FeatureType,
)


def generator(features: Set[str], feat_type: FeatureType) -> Generator[Tuple, None, None]:
    return ((aggregation(feat, feat_type), condition(feat, feat_type)) for feat in select_features(features, feat_type))


def select_features(features: Set[str], feat_type: FeatureType) -> Generator[str, None, None]:
    return filter((lambda feat: feat in get_features_by_type(feat_type)), features)


@lru_cache
def aggregation(feature: str, feat_type: FeatureType):
    return TYPE_TO_AGGREGATION[feat_type][feature]


@lru_cache
def condition(feature: str, feat_type: FeatureType):
    return TYPE_TO_CONDITION[feat_type][feature]


@lru_cache
def get_features_by_type(feat_type: FeatureType):
    return TYPE_TO_FEATURES[feat_type]
