from typing import Callable, Set, Generator

from pyspark.sql import DataFrame, functions as f

from .const import FeatureType, InputSchema
from .features import generator, get_features_by_type
from .utils import multi_join


def calc_stat(df: DataFrame, features: Set[str] = get_features_by_type(FeatureType.ALL)) -> DataFrame:
    ''' Return spark dataframe with transformed user statistic.

    Parameters
    ----------
    df : spark.sql.DataFrame
        Spark dataframe with user sessions data

        ============================= ============================
        number_tuple_id               integer (nullable = false)
        interlocutor_number_tuple_id  integer (nullable = true)
        is_outgoing                   boolean (nullable = false)
        s_dt                          timestamp (nullable = true)
        s_dur                         integer (nullable = true)
        ============================= ============================
    features : Set[str]
        The set of property names that need to be calculated

    Returns
    -------
    spark.sql.DataFrame
        Spark dataframe with transformed user statistic.
    '''
    return multi_join((
        calc_special_stat(df, features, FeatureType.BASIC, calculate_basic),
        calc_special_stat(transform_to_period_df(df, FeatureType.YEAR), features, FeatureType.YEAR, calculate_period_factory(FeatureType.YEAR)),
        calc_special_stat(transform_to_period_df(df, FeatureType.MONTH), features, FeatureType.MONTH, calculate_period_factory(FeatureType.MONTH)),
        calc_special_stat(transform_to_period_df(df, FeatureType.DAY), features, FeatureType.DAY, calculate_period_factory(FeatureType.DAY)),
        calc_special_stat(transform_to_week_df(df), features, FeatureType.WEEK, calculate_basic),
    ))


def calc_special_stat(df: DataFrame, features: Set[str], feature_type: FeatureType, calc_func: Callable) -> DataFrame:
    return multi_join(calc_func(df, agg, cond) for agg, cond in generator(features, feature_type))


def calculate_basic(df, agg, cond):
    return df.where(cond).groupBy(InputSchema.NUMBER_TUPLE_ID.value).agg(agg)


def calculate_period_factory(period: FeatureType):
    return lambda df, agg, cond: (
        df.where(cond)
        .groupBy(InputSchema.NUMBER_TUPLE_ID.value, 'period')
        .agg(f.countDistinct(f.col(InputSchema.INTERLOCUTOR_NUMBER_TUPLE_ID.value)).alias(period.value))
        .groupBy(InputSchema.NUMBER_TUPLE_ID.value)
        .agg(agg)
    )


def transform_to_period_df(df: DataFrame, period: FeatureType) -> DataFrame:
    return df.withColumn('period', f.date_trunc(period.value, f.col(InputSchema.S_DT.value)))


def transform_to_week_df(df: DataFrame) -> DataFrame:
    return df.withColumn('dayofweek', f.dayofweek(InputSchema.S_DT.value))
