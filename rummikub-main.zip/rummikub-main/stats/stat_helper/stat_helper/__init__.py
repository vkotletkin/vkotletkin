from .stat_calculator import calc_stat


__all__ = ['calc_stat']
