from itertools import filterfalse


def multi_join(it, on='number_tuple_id', t='fullouter'):
    result_df = None
    for df in filterfalse(lambda x: x is None, it):
        result_df = df if result_df is None else result_df.join(df, on, t)
    return result_df
