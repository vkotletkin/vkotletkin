## Build python package

Before building, do not forget to update the version in "pyproject.toml".

```bash
rm -rf dist 
python3 -m build
```

## Uploading to the nexus

```bash
python3 -m twine upload -u ${NEXUS_USER} -p ${NEXUS_PASSWORD} --repository-url https://nexus.baltinfocom.ru/repository/pypi/ dist/*
```